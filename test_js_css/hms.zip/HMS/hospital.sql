-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 12, 2016 at 09:36 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis`
--

CREATE TABLE IF NOT EXISTS `diagnosis` (
  `diagnosisid` int(11) NOT NULL AUTO_INCREMENT,
  `patid` varchar(100) NOT NULL,
  `diagnosis` text NOT NULL,
  `treat` text NOT NULL,
  `discription` text NOT NULL,
  PRIMARY KEY (`diagnosisid`),
  KEY `patid` (`patid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `diagnosis`
--

INSERT INTO `diagnosis` (`diagnosisid`, `patid`, `diagnosis`, `treat`, `discription`) VALUES
(3, '2016-06-27-1', 'malaria fever', 'panadol 25', '2x3');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(100) NOT NULL,
  `ReminderDate` varchar(12) NOT NULL,
  `Note` text NOT NULL,
  `Time` time NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`ID`, `FullName`, `ReminderDate`, `Note`, `Time`) VALUES
(1, 'bb', '2016-07-10', 'bb', '838:59:59'),
(2, 'nnn', '2016-07-15', 'nm,.', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE IF NOT EXISTS `patients` (
  `No` varchar(100) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `age` int(45) NOT NULL,
  `sex` varchar(45) NOT NULL,
  `tel` int(20) NOT NULL,
  `address` text NOT NULL,
  `dateEntry` date NOT NULL,
  PRIMARY KEY (`No`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`No`, `fname`, `lname`, `age`, `sex`, `tel`, `address`, `dateEntry`) VALUES
('2016-06-27-1', 'kafeero', 'samuel', 20, 'Male', 978654, 'mbarara', '2016-06-27'),
('2016-07-09', 'sdfg', 'ss', 22, 'Male', 9876543, 'ASDFV', '2016-07-09');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(100) NOT NULL,
  `PRICE` varchar(100) NOT NULL,
  `pcode` varchar(100) NOT NULL,
  `empId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `name`, `qty`, `total`, `code`, `date`, `time`, `PRICE`, `pcode`, `empId`) VALUES
(1, 'kamadol', '2', '24000', '2016-06-0001-STO', '2016-06-21', '0 : 05 : 23', '12000', '233', 1),
(2, 'kamadol', '1', '220000', '2016-07-0002-STO', '2016-07-12', '0 : 13 : 07', '220000', '233', 8),
(3, 'kamadol', '2', '440000', '2016-07-0002-STO', '2016-07-12', '0 : 15 : 36', '220000', '233', 8),
(4, 'kamadol', '2', '440000', '2016-07-0004-STO', '2016-07-12', '0 : 18 : 29', '220000', '233', 8);

-- --------------------------------------------------------

--
-- Table structure for table `productlist`
--

CREATE TABLE IF NOT EXISTS `productlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pcode` varchar(100) NOT NULL,
  `pdec` varchar(100) NOT NULL,
  `pleft` int(100) NOT NULL,
  `psold` int(100) NOT NULL,
  `pprice` varchar(100) NOT NULL,
  `qtytype` int(100) NOT NULL,
  `pname` varchar(200) NOT NULL,
  `dateIn` date NOT NULL,
  `expiryDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `productlist`
--

INSERT INTO `productlist` (`id`, `pcode`, `pdec`, `pleft`, `psold`, `pprice`, `qtytype`, `pname`, `dateIn`, `expiryDate`) VALUES
(1, '233', 'high defination', 47, -2, '220000', 1, 'kamadol', '2015-06-25', '2020-06-25'),
(5, '342', 'high quality', 10, 0, '20000', 1, 'glass', '2016-06-26', '2080-06-26');

-- --------------------------------------------------------

--
-- Table structure for table `producttype`
--

CREATE TABLE IF NOT EXISTS `producttype` (
  `typeId` int(100) NOT NULL AUTO_INCREMENT,
  `typeName` varchar(209) NOT NULL,
  PRIMARY KEY (`typeId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `producttype`
--

INSERT INTO `producttype` (`typeId`, `typeName`) VALUES
(1, 'Eye wear');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `PRICE` varchar(100) NOT NULL,
  `pcode` varchar(100) NOT NULL,
  `empId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `sales`
--


-- --------------------------------------------------------

--
-- Table structure for table `socode`
--

CREATE TABLE IF NOT EXISTS `socode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `socode`
--

INSERT INTO `socode` (`id`, `code`) VALUES
(1, '1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `sex` varchar(7) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `sex`, `username`, `password`, `role`) VALUES
(8, 'teta', 'joan', 'Female', 'teta', 'teta', 'administrator');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `diagnosis`
--
ALTER TABLE `diagnosis`
  ADD CONSTRAINT `diagnosis_ibfk_1` FOREIGN KEY (`patid`) REFERENCES `patients` (`No`) ON DELETE CASCADE ON UPDATE CASCADE;
