<?php 
session_start();
include 'configuration.php';

if(isset($_SESSION['SESS_MEMBER_ID']))
{
unset($_SESSION['SESS_MEMBER_ID']);
unset($_SESSION['user']);

header("Location:../index.php");

echo '<script> location="../index.php?action=logout%out"; </script>';
exit;
}
?>