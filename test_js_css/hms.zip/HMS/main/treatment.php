<?php
	require_once('../auth.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>vine eye center</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="../style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="tcal.js"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="css/default.css"/>
		<script type="text/javascript" src="js/script.js"></script> 


<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
-->
</style>

<style>
#result {
	height:20px;
	font-size:16px;
	font-family:Arial, Helvetica, sans-serif;
	color:#333;
	padding:5px;
	margin-bottom:10px;
	background-color:#FFFF99;
}
#country{
	border: 1px solid #999;
	background: #EEEEEE;
	padding: 5px 10px;
	box-shadow:0 1px 2px #ddd;
    -moz-box-shadow:0 1px 2px #ddd;
    -webkit-box-shadow:0 1px 2px #ddd;
}
.suggestionsBox {
	position: absolute;
	left: 10px;
	margin: 0;
	width: 268px;
	top: 40px;
	padding:0px;
	background-color: #000;
	color: #fff;
}
.suggestionList {
	margin: 0px;
	padding: 0px;
}
.suggestionList ul li {
	list-style:none;
	margin: 0px;
	padding: 6px;
	border-bottom:1px dotted #666;
	cursor: pointer;
}
.suggestionList ul li:hover {
	background-color: #FC3;
	color:#000;
}
ul {
	font-family:Arial, Helvetica, sans-serif;
	font-size:11px;
	color:#FFF;
	padding:0;
	margin:0;
}

.load{
background-image:url(loader.gif);
background-position:right;
background-repeat:no-repeat;
}

#suggest {
	position:relative;
}
.combopopup{
	padding:3px;
	width:268px;
	border:1px #CCC solid;
}

</style>	
</head>

<body onLoad="document.getElementById('country').focus();">
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
		
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

       <table width="669" align="center">
        <tr>
          <td height="43" colspan="2"><h2 align="center"><span class="style1">Doctor's diagnosis Form </span></h2></td>
        </tr>
        <tr>
           <td width="417">
		  <a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  		  <a href="viewDiagno.php?action=add"><button>View Diagnosed</button></a>&nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;
	
	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
         
    </table>

  </div>
  <?php
			
			require('../configuration.php');

			$id = $_REQUEST['viewid'];

			$qry = mysql_query("select * from diagnosis d,patients p where d.patNo=p.No AND d.patNo = '$id'");
			if(!$qry){echo mysql_error();}else{

				while($row = mysql_fetch_array($qry)){
					$id = $row['No'];
					$passport = $row['pport'];
					
				}
			}

			
			

		?>
  <!--###########################################################################-->
 <div class="add-user-main-panel">
<form action="treatmentcode.php" method="get" class="register">

	 <table width="669" align="center">
	 	<tr>
			<td width="122" rowspan="5"><img src="profile/<?php echo $passport; ?>" alt="Passport" width="147" height="137" /><br />
				<input id="textfield"type="hidden" name="pNo" value="<?php echo $id; ?>" />
				
		    <td width="535">Make sure you use valid information for this registration, because it is very important to this institute for future use. </td>
	 	</tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
     </table>
<hr />
	 <table width="669" align="center">
    <tr> 
				
					<td><input type="button" value="Add Treatment" onClick="addRow('dataTable')" /> </td>
					<td><input type="button" value="Remove Treatment" onClick="deleteRow('dataTable')"  /> </td>
					<p>(All actions apply only to entries with check marked check boxes only.)</p>
				
               <table id="dataTable" width="669">
                  <tbody>
                    <tr>
                      <p>
						<td><input type="checkbox" required="required" name="chk[]" checked="checked" /></td>
						<td>
							<label>Medicine Name</label>
							<input type="text" required="required"  name="medicineName[]" id="country" onkeyup="suggest(this.value);" onblur="fill();">
						 </td>
						 
						 </td>
							</p>
                    </tr>
                    </tbody>
                </table>
				<div class="clear"></div>
	  </table>

<hr />

 <table width="669" align="center">
		<tr>
		  <td bgcolor="#000000"><span class="style3">Before submitting, make sure that all the information you used is correct</span></td>
	    </tr>
	 </table>
	 
<hr/>
	  <table width="669" align="center">
		<tr>
		  <td colspan="2"><label for="Submit"></label>
	      <input type="submit" name="submit" value="Submit" id="Submit" /></td></form>
        </tr>
	 </table>


    
  </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js"></script>
<script>
function suggest(inputString){
		if(inputString.length == 0) {
			$('#suggestions').fadeOut();
		} else {
		$('#country').addClass('load');
			$.post("autosuggestmedicine.php", {queryString: ""+inputString+""}, function(data){
				if(data.length >0) {
					$('#suggestions').fadeIn();
					$('#suggestionsList').html(data);
					$('#country').removeClass('load');
				}
			});
		}
	}

	function fill(thisValue) {
		$('#country').val(thisValue);
		setTimeout("$('#suggestions').fadeOut();", 600);
	}

</script>
</body>
<!-- Start of StatCounter Code for Default Guide -->

</html>