<?php
	require_once('../auth.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>vine clinic</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />

<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
.style20 {font-size: 14px}
-->
</style>
</head>

<body>
<div class="add-container">
  <div class="banner-div">
     <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

      <table width="669" align="center">
        <tr>
          <td height="43" colspan="2"><h2 align="center"><span class="style2"> Welcome to individual patient view </span></h2></td>
        </tr>
        <tr>
        <td width="417">
		  	<a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  <a href="viewDiagno.php?action=view"><button>View Diagnosed</button></a>&nbsp;
		  	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;


	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td> 
	</tr>
    </table>

  </div>
  <!--###########################################################################-->
 <div class="add-user-main-panel">
	 <table width="669" align="center">
	 	<?php

			require('../configuration.php');

			$id = $_REQUEST['viewid'];

			$qry = mysql_query("select * from patients p, diagnosis d where d.patNo=p.No AND  d.patNo = '$id'");
			if(!$qry){echo mysql_error();}else{

				while($row = mysql_fetch_array($qry)){
					$id = $row['No'];
					$passport = $row['pport'];
					$title = $row['title'];
					$firstname = $row['fname'];
					$middlename = $row['mname'];
					$lastname = $row['lname'];
					$gender = $row['gender'];
					$cornea = $row['cornea'];
					$A_C  = $row['A_C'];
					$pupil = $row['pupil'];
					$verification = $row['verify'];
					$lence = $row['lence'];
					$Vitroeus = $row['Vitroeus'];
					$retina = $row['retina'];
					$opticalnerve = $row['opticalnerve'];
					$retina = $row['retina'];
					$C_D_R  = $row['C_D_R'];
					$pinhole = $row['pinhole'];
					$complaint = $row['complaint'];
					$PD = $row['PD'];
					$Pressure = $row['Pressure'];
					$eyelid = $row['eyelid'];
					$conj_ctive = $row['conj_ctive'];

					$a = $row['a'];
					$b = $row['b'];
					$c = $row['c'];
					$d = $row['d'];
					$e = $row['a2'];
					$g = $row['b2'];
					$h = $row['c2'];
					$i = $row['d2'];
					
					$j = $row['a3'];
					$k = $row['b3'];
					$l = $row['c3'];
					$m = $row['d3'];
						
					$n = $row['a4'];
					$o= $row['b4'];
					$p = $row['c4'];
					$q = $row['d4'];
					$r = $row['desease'];
					
					$cornea2 = $row['cornea2'];
					$A_C2  = $row['A_C2'];
					$pupil2 = $row['pupil2'];
					$lence2 = $row['lence2'];
					$Vitroeus2 = $row['Vitroeus2'];
					$retina2 = $row['retina2'];
					$opticalnerve2 = $row['opticalnerve2'];
					$retina2 = $row['retina2'];
					$C_D_R2  = $row['C_D_R2'];
					$pinhole2 = $row['pinhole2'];
					$complaint2 = $row['complaint2'];
					$PD2 = $row['PD2'];
					$Pressure2 = $row['Pressure2'];
					$eyelid2 = $row['eyelid2'];
					$conj_ctive2 = $row['conj_ctive2'];
					$dd = $row['desease'];

				}
			}


		?>
        <tr>
			<td width="345"><img src="profile/<?php echo $passport; ?>" alt="Passport" width="147" height="137" /><br /></td>
	 	    <td width="312"><img src="profile/<?php echo $verification; ?>" alt="verification tick" width="147" height="137" /></td>
        </tr>

		<tr>
		<td><span class="style20">Names: <font color="green"><?php echo $title; ?> <?php echo $firstname; ?> <?php echo $middlename; ?> <?php echo $lastname; ?> </font></span></td>
	   </tr>
		<tr>
		  <td><span class="style20">Gender: <font color="green"><?php echo $gender; ?></font></span></td>
		  
	   </tr>
	   <tr>
		  <td bgcolor="#000099"><h3 class="style3">Left Eye </h3></td>
		  <td bgcolor="#000099"><h3 class="style3">Right Eye</h3></td>
	   </tr>
		<tr>
		  <td><span class="style20">Cornea: <font color="green"><?php echo $cornea; ?></font></span></td>
		  <td><span class="style20">Cornea: <font color="green"><?php echo $cornea2; ?></font></span></td>
	   </tr>
	   <tr>
		  <td><span class="style20">A.C: <font color="green"><?php echo $A_C; ?></font></span></td>
		  <td><span class="style20">A.C: <font color="green"><?php echo $A_C2; ?></font></span></td>
	   </tr>
	   <tr>
		  <td><span class="style20">Pupil: <font color="green"><?php echo $pupil; ?></font></span></td>
		  <td><span class="style20">Pupil: <font color="green"><?php echo $pupil2; ?></font></span></td>
	   </tr>
	    <tr>
	      <td><span class="style20">Lence: <font color="green"><?php echo $lence; ?></font></span></td>
	      <td><span class="style20">Lence: <font color="green"><?php echo $lence2; ?></font></span></td>
       </tr>
	   <tr>
	      <td><span class="style20">Vitroeus: <font color="green"><?php echo $Vitroeus; ?></font></span></td>
	      <td><span class="style20">Vitroeus: <font color="green"><?php echo $Vitroeus2; ?></font></span></td>
       </tr>
	   <tr>
	      <td><span class="style20">retina: <font color="green"><?php echo $retina; ?></font></span></td>
	      <td><span class="style20">retina: <font color="green"><?php echo $retina2; ?></font></span></td>
       </tr>
	   <tr>
	      <td><span class="style20">Optical nerve: <font color="green"><?php echo $opticalnerve; ?></font></span></td>
	      <td><span class="style20">Optical nerve: <font color="green"><?php echo $opticalnerve2; ?></font></span></td>
       </tr>
	   <tr>
	      <td><span class="style20">C.D.R : <font color="green"><?php echo $C_D_R ; ?></font></span></td>
	      <td><span class="style20">C.D.R : <font color="green"><?php echo $C_D_R2 ; ?></font></span></td>
       </tr>
	   <tr>
	      <td><span class="style20">Pinhole <font color="green"><?php echo $pinhole; ?></font></span></td>
	      <td><span class="style20">Pinhole <font color="green"><?php echo $pinhole2; ?></font></span></td>
       </tr>
	   <tr>
	      <td><span class="style20">P.D: <font color="green"><?php echo $PD; ?></font></span></td>
	      <td><span class="style20">P.D: <font color="green"><?php echo $PD2; ?></font></span></td>
       </tr>
	   <tr>
	      <td><span class="style20">Complaint : <font color="green"><?php echo $complaint ; ?></font></span></td>
	      <td><span class="style20">Complaint : <font color="green"><?php echo $complaint2 ; ?></font></span></td>
       </tr> 
	   <tr>
	      <td><span class="style20">Pressure : <font color="green"><?php echo $Pressure ; ?></font></span></td>
	      <td><span class="style20">Pressure : <font color="green"><?php echo $Pressure2 ; ?></font></span></td>
       </tr> 
	   <tr>
	      <td><span class="style20">Eye lid : <font color="green"><?php echo $eyelid ; ?></font></span></td>
	      <td><span class="style20">Eye lid : <font color="green"><?php echo $eyelid2 ; ?></font></span></td>
       </tr> <tr>
	      <td><span class="style20">Conjuactive : <font color="green"><?php echo $conj_ctive ; ?></font></span></td>
	      <td><span class="style20">Conjuactive : <font color="green"><?php echo $conj_ctive2 ; ?></font></span></td>
		  
		   
       </tr>
	 
      
     </table>
	 <table border="1" align="left" style="margin-left:40px;" ">
	 <tr>
	 <td colspan="4"><h3>Auto-Refraction</td>
	 </tr>
	 <tr>
	 <td>
	 S
	 </td>
	 <td>
	 C
	 </td>
	 <td>
	AX
	 </td>
	 <td>
	 ADD
	 </td>
	 </tr>
	<tr>
	      <td> <font color="green"><?php echo $a ; ?></font></td>
	      <td> <font color="green"><?php echo $b ; ?></font></td>
		  <td> <font color="green"><?php echo $c ; ?></font></td>
	      <td> <font color="green"><?php echo $d ; ?></font></td>
       </tr>
	   </table>
	    <table border="1" align="left"  width="160">
	 <tr>
	<td colspan="4"><h3> Subjective Refraction</h3></td>
	 <tr>
	 </tr>
	 <td>
	 S
	 </td>
	 <td>
	 C
	 </td>
	 <td>
	AX
	 </td>
	 <td>
	 ADD
	 </td>
	 </tr>
	<tr>
	      <td> <font color="green"><?php echo $e ; ?></font></td>
	      <td> <font color="green"><?php echo $g ; ?></font></td>
		  <td> <font color="green"><?php echo $h ; ?></font></td>
	      <td> <font color="green"><?php echo $i; ?></font></td>
       </tr>
	   </table>
	   
	  <table border="1" align="right" style="margin-right:90px;" >
	 <tr>
	 <td colspan="4"><h3>Auto-Refraction</td>
	 </tr>
	 <tr>
	 <td>
	 S
	 </td>
	 <td>
	 C
	 </td>
	 <td>
	AX
	 </td>
	 <td>
	 ADD
	 </td>
	 </tr>
	<tr>
	      <td> <font color="green"><?php echo $j ; ?></font></td>
		  <td> <font color="green"><?php echo $k ; ?></font></td>
	      <td> <font color="green"><?php echo $l ; ?></font></td>
	      <td> <font color="green"><?php echo $m ; ?></font></td>
       </tr>
	   </table>
	    <table border="1" align="left" style="margin-left:75px;" width="160">
	 <tr>
	<td colspan="4"><h3> Subjective Refraction</h3></td>
	 <tr>
	 </tr>
	 <td>
	 S
	 </td>
	 <td>
	 C
	 </td>
	 <td>
	AX
	 </td>
	 <td>
	 ADD
	 </td>
	 </tr>
	<tr>
	      <td> <font color="green"><?php echo $n ; ?></font></td>
	      <td> <font color="green"><?php echo $o ; ?></font></td>
		  <td> <font color="green"><?php echo $p ; ?></font></td>
	      <td> <font color="green"><?php echo $q ; ?></font></td>
       </tr>
	   </table>
	   <table width="669" align="center">
	   <tr>
	      <td><span class="style20"><font color="red">Disease : <font color="Blue"><?php echo $r ; ?></font></span></td>
	      <td><span class="style20"><font color="red" style="text-align:center;"align="center">Disease : <font color="Blue"><?php echo $dd ; ?></font></span></td>
       </tr>
	   </table>
	   
	   <br/>
	  <table width="669" align="center">
	    <tr>
	 <!--  <td><a href="Diagnosis.php?viewid=<?php echo $id; ?>"><button>Complete Diagnosis</button></a></td>-->
	   	<td bgcolor="#000000"><span class="style3">Please verify that the information in correct</span></td></tr>
	   <tr><td><a href="verifypatientInfor.php?verifyid=<?php echo $id; ?>"><button>Verify if this information is correct</button></a></td>
	   </tr>
	   </table >
	   <hr/>
 	</div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
