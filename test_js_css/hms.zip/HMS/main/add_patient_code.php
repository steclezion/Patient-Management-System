<?php
	require_once('../auth.php');
require('../configuration.php');

$target_path = "profile/";
$target_path = $target_path . basename( $_FILES['uploadedfile']['name']);
if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)){
$image = basename( $_FILES['uploadedfile']['name']);
$No = $_POST['No'];
$title = $_POST['title'];
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$gender = $_POST['gender'];
$dob = $_POST['dob'];
$age = $_POST['age'];
$tel = $_POST['tel'];
$address = $_POST['address'];
$dEntry = $_POST['dEntry'];


/*
$qry1 = mysql_query("
	insert into staffs_backup
	(
		pport,
		title,
		fname,
		mname,
		lname,
		gender,
		dob,
		year_of_service,
		service_start_date,
		gradelvl,
		category,
		cert,
		salary,
		allowance,
		ext_ao_slr,
		ext_ao_pension,
		ext_ao_tax,
		ext_ao_other,
		verify
	)
	values(
		'$image',
		'$title',
		'$fname',
		'$mname',
		'$lname',
		'$gender',
		'$dob',
		'$year_of_service',
		'$service_start_date',
		'$gradelvl',
		'$category',
		'$cert',
		'$salary',
		'$allowance',
		'$ext_ao_slr',
		'$ext_ao_pension',
		'$ext_ao_tax',
		'$ext_ao_other',
		'unverified.png'
	)
	");
*/

$qry = mysql_query("
	insert into patients
	
	values(
		'$No',
		'$image',
		'$title',
		'$fname',
		'$mname',
		'$lname',
		'$gender',
		'$dob',
		'$age',
		'$tel',
		'$address',
		'$dEntry',
		'new'
	)
	");

			if($qry){

				echo ' Your data has been inserted, Please wait... ';

				echo '<script type="text/javascript">

						var myVar=setInterval(function(){myTimer()},2000);

				function myTimer()
				{
					window.location="viewpat.php";

				}
			</script>';
			}else {	echo mysql_error();	}

	}
	else{
		echo mysql_error();
		}

?>