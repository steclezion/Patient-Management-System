<?php
include('../configuration.php');
if($_POST)
{
$q=$_POST['search'];
$sql_res=mysql_query("select product_name from products where product_name like '%$q%'  order by product_id LIMIT 10");
while($row=mysql_fetch_array($sql_res))
{
$username=$row['product_name'];
?>
<div class="show" align="left">
<span class="name"><?php echo $username; ?></span>&nbsp;<br/>
</div>
<?php
}
}
?>
