<?php
include('../configuration.php');
	$id=$_GET['product_id'];
	$result = $db->prepare("DELETE FROM products WHERE product_id= :memid");
	$result->bindParam(':memid', $id);
	$result->execute();
	header("location: viewproducts.php");

?>