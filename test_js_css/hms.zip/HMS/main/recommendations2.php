<?php
	require_once('../auth.php');
		include('../configuration.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Vine eye center management system</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />

<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<!--sa poip up-->
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>



<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
.style19 {font-size: 24px; font-family: Geneva, Arial, Helvetica, sans-serif; }
-->
</style>



 <script type="text/javascript">
function confirmationDelete(anchor)
{
   var conf = confirm('beform you comfirm make sure you have given a client/patient the right services?');
   if(conf)
      window.location=anchor.attr("href");
}
</script>
  
  
</head>
<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
			
		
			
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

      <table width="669" align="center">
        <tr>
          <td height="20" colspan="3"><h3 align="center"><span class="style1"> View Doctor Recommendations here</span></h2></td>
        </tr>
        <tr>
          <td width="350">
		 <a href="index.php?action=index"><button>Home</button></a> &nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;
</td>
<td>
	<font color="red" size="1"> User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
      

        </tr>
    </table>

  </div>
  <!--###########################################################################-->
 <div class="add-user-main-panel">
 
	<table id="resultTable" border="0"data-responsive="table">
	<thead>
		<tr>
			<th width="25%">Names </th>
			<th width="11%"> Treatment </th>
			<th width="11%"> Procedures </th>
			<th colspan="4"> <center>Action here <center></th>
		</tr>
	</thead>
	<tbody>
		
			<?php

				$sql=mysql_Query ("SELECT Distinct patients.No,patients.fname,patients.lname,treatment.medicineName,procedurers.procname
FROM patients
LEFT JOIN treatment
ON patients.No=treatment.pNo
LEFT JOIN procedurers
ON patients.No=procedurers.paNo
 GROUP BY procedurers.paNo ");
				while ($row = mysql_fetch_assoc($sql)) {
			?>
			<tr class="record">
		<td>	<?php echo $row['No'].'-'.$row['fname'].'-'.$row['lname'];?></td>
			<td><?php echo $row['medicineName']; ?></td>
			<td><?php echo $row['procname']; ?></td>
			
			<td><a align="center"  rel="facebox" href="tretamentList.php?No=<?php echo $row['No']; ?>" title="Confirm service">  More Treatment</a><td>
			<td><a align="center"  rel="facebox" href="procedureList.php?No=<?php echo $row['No']; ?>" title="Confirm service">  More Procedures</a><td>
			</tr>
	<?php
				}
			?>
		
	</tbody>
</table>
<div class="clearfix"></div>
</div>

<div class="clearfix"></div><div class="clearfix">
 </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
