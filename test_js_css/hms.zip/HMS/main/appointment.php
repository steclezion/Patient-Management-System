<?php 
include '../auth.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>vine clinic</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="tcal.css" />
<script type="text/javascript" src="tcal.js"></script>
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
-->
</style>
</head>
		<SCRIPT TYPE="text/javascript"> 
 
var message="Sorry, right-click has been disabled"; 

function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 

</SCRIPT>
<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
			<script type="text/javascript">

function getAge(){
    var dob = document.getElementById('date').value;
    dob = new Date(dob);
    var today = new Date();
    var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
    document.getElementById('age').value=age;
}

</script>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">	
	<link rel="stylesheet" href="reminder.css"/>
	<script src="js/jquery-1.4.2.min.js" type="text/javascript"></script>

<script type="text/javascript">
/*var auto_refresh = setInterval(
function ()
{
$('#as').load('backup.php').fadeIn("slow");
}, 1000); // refresh every 10000 milliseconds
*/
</script>
<SCRIPT TYPE="text/javascript"> 
 
var message="Sorry, right-click has been disabled"; 

function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 

</SCRIPT> 
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<div id="as"></div>


 <!--back up-->
  
 
<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">	
	<link rel="stylesheet" href="style.css"/>
	<script src="js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script type="text/javascript">
  $('.add-event').live('click', function()
  {
     var String = $('#EventForm').serialize(); 
	 $('#event-result').hide();
	 $('#event-result').show();
	 $('.result').html('<img src="loading.gif" width="30" alt="Loading..."/>').fadeIn('slow');
     $.ajax
      ({
      type: "POST",
      url:  "data/action.php",	
      data: String,
      cache: false,
      success: function(data)
      {  
		  $('#event-result').show();
          if(data == 1)
		  {
		   $('.result').html('<span class="event-result">Patient Name & Appointment could not be empty.</span>').fadeIn('slow');	
		  }
          else if(data == 2)
		  {
		   $('.result').html('<span class="event-result">Sorry Patient Name or Appointment is not valid.</span>').fadeIn('slow');
		  }
          else if(data == 3)
		  {
           $('.result').html('<span class="event-result">Thank you ! You will get reminder before one week from reminder date.</span>').fadeIn('slow'); 		
		  }		
          else if(data == 4)
		  {
           $('.result').html('<span class="event-result">Sorry you cant use previous date for upcoming reminder.</span>').fadeIn('slow'); 		
		  }
          else if(data == 5)
		  {
           $('.result').html('<span class="event-result">Please select correct date.</span>').fadeIn('slow'); 		
		  }
          else if(data == 6)
		  {
           $('.result').html('<span class="event-result">Event allready exist with date.</span>').fadeIn('slow'); 		
		  }			  
		  else
		  {
           $('.result').html('Event added successfully.').fadeIn('slow'); 			  
           $(".loadevent").prepend($(data).fadeIn('slow')).show(); 
		   
		  }	 		  
      }
      });	     
  });
</script>




<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js"></script>
<script>
function suggest(inputString){
		if(inputString.length == 0) {
			$('#suggestions').fadeOut();
		} else {
		$('#country').addClass('load');
			$.post("autocomplete.php", {queryString: ""+inputString+""}, function(data){
				if(data.length >0) {
					$('#suggestions').fadeIn();
					$('#suggestionsList').html(data);
					$('#country').removeClass('load');
				}
			});
		}
	}

	function fill(thisValue) {
		$('#country').val(thisValue);
		setTimeout("$('#suggestions').fadeOut();", 600);
	}

</script>	
<?php 
   $conn = mysql_connect('localhost', 'root', '');
   mysql_select_db('HIMS', $conn);
   $days = range(1,31);
   $months = range(1,12);
   $years = range(2016,2020);
   $getrecoverynoti = mysql_query("select ID, FullName, Note, ReminderDate from members where members.ReminderDate >= DATE(now()) and members.ReminderDate <= DATE_ADD(DATE(now()), INTERVAL 10 DAY) and ReminderDate >= NOW() ORDER BY ABS( DATEDIFF( ReminderDate, NOW())) Limit 10")or die(mysql_error());
   $countrecovery = mysql_num_rows($getrecoverynoti);
?>
<body>
</div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

       <table width="669" align="center">
        <tr>
          <td height="43" colspan="2"><h2 align="center"><span class="style1"> Welcome to patient's Form </span></h2></td>
        </tr>
        <tr>
          <td width="417">
		  	<a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  <a href="add_patient.php?action=add"><button>New Patient</button></a>&nbsp;
		  <a href="viewpat.php?action=view"><button>View</button></a>&nbsp;

	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
          <td width="240">
		  	<form name="searchForm" action="search_index_patient.php" method="POST">
		  		<input type="textfield" name="search" placeholder="Search patient" />
				<button type="submit">Search</button>
		  	</form>
		  </td>
        </tr>
    </table>
  </div>
   <!--###########################################################################-->
 <div class="add-user-main-panel">
<div class="header">
  

<!-- <div style="width:100%; background:#3B5998; border: #000 1px solid;"></div>
-->
<div class="main_content">
<div class="wrapper">
<div class="head">
<div class="head_title">
</div>
</div>


 <div class="eventform">
<table  align="center" class="app-form">
<tr>
<td> <h5 align="center">Make an appointment here</h5></td>
<tr>
<form id="EventForm">
 <tr>
   <td> 
    <p> <b>Patient ID</b></p>
    <input type="text" placeholder=" patient id" id="reminder-input" name="CName">
   </td>
 </tr>
 <tr>
 <td> 
  <p> <b>Appointment</b></p>
 <textarea placeholder="Appointment" id="Note" name="CNote"></textarea></td>
 </tr>
 <tr>
    <td> 
	  <p> <b>Select Date</b></p>
	   <select name="dd">
	      <option value="DD" selected>DD</option>
		  <?php foreach($days as $day) { ?>
		  <option value="<?php echo $day; ?>"><?php echo $day; ?></option>
		  <?php } ?>
	   </select>
	   <select name="mm">
	      <option value="MM" selected>MM</option>
		  <?php foreach($months as $month) { ?>
		  <option value="<?php echo $month; ?>"><?php echo $month; ?></option>
		  <?php } ?>
	   </select>
	   
	   <select name="yyyy">
	      <option value="YYYY" selected>YYYY</option>
		  <option ><?php echo date("Y"); ?></option>
	   </select>	   
	</td>
 </tr> 
  <tr>
 <td style="padding-bottom:10px;">  
    <p></p>
    <input type="button" value="Create Event" class="add-event"> </td>
 </tr>
 <tr id="event-result" style="display:none">
 <td style="padding-bottom:20px;" class="result">  
    Result here
 </td>
 </tr>
 </form>
</table>
</div>

    
<style>
#can
{
margin-left:250px;
text-align:center;
}
</style>
</div>
</div>
</div>
</div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>