<?php
	require_once('../auth.php');
		include('../configuration.php');

?>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<table id="resultTable" data-responsive="table" style="text-align: left;">
	<thead>
		<tr>
			<th width="5%"> Procedure Name </th>
		</tr>
	</thead>
	<tbody>
		
			
			<?php
                       $id=$_GET['No'];
				$sql=mysql_Query ("SELECT *  From procedurers WHERE status='unconfirmed' AND paNo='$id'");
				while ($row = mysql_fetch_assoc($sql)) {
			?>
			<tr class="record">
			<td><?php echo $row['procname']; ?></td>
			
			
			</tr>
	<?php
				}
			?>
			</td>
			
			</tr>

		
	</tbody>
</table>