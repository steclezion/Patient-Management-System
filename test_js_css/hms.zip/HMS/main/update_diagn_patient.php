<?php
	require_once('../auth.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Vine eye center manage</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="../style.css" rel="stylesheet" type="text/css" />

<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
-->
</style>
</head>

<body>
<div class="add-container">
  <div class="banner-div">
    <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">
 <table width="669" align="center">
        <tr>
          <td height="20" colspan="2"><h5 align="center"><span class="style1"> UPdate last part on diagnosiss </span></h5></td>
        </tr>
        <tr>
          <td width="417">
		  <a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  <a href="viewDiagno_techn.php?action=add"><button>View Diagnosed</button></a>&nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;

	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>
		  </td>

    </table>
  </div>
  <!--###########################################################################-->
  <?php
			
			require('../configuration.php');

		$id = $_REQUEST['updateid'];

			$qry = mysql_query("select * from patients p, diagnosis d where d.patNo=p.No GROUP BY d.patNo");
			if(!$qry){echo mysql_error();}else{

				while($row = mysql_fetch_array($qry)){
				$id = $row['No'];
					$passport = $row['pport'];
					$title = $row['title'];
					$firstname = $row['fname'];
					$middlename = $row['mname'];
					$lastname = $row['lname'];
					$gender = $row['gender'];
					$cornea = $row['cornea'];
					$A_C  = $row['A_C'];
					$pupil = $row['pupil'];
					$verification = $row['verify'];
					$lence = $row['lence'];
					$Vitroeus = $row['Vitroeus'];
					$retina = $row['retina'];
					$opticalnerve = $row['opticalnerve'];
					$retina = $row['retina'];
					$C_D_R  = $row['C_D_R'];
					$pinhole = $row['pinhole'];
					$complaint = $row['complaint'];
					$PD = $row['PD'];
					$Pressure = $row['Pressure'];
					$eyelid = $row['eyelid'];
					$vission = $row['vission'];
					$vission2 = $row['vission2'];
					$v = $row['V_A'];
					$glass = $row['glasses'];
					
					$a = $row['a'];
					$b = $row['b'];
					$c = $row['c'];
					$d = $row['d'];
					$e = $row['a2'];
					$g = $row['b2'];
					$h = $row['c2'];
					$i = $row['d2'];
					
					$j = $row['a3'];
					$k = $row['b3'];
					$l = $row['c3'];
					$m = $row['d3'];
						
					$n = $row['a4'];
					$o= $row['b4'];
					$p = $row['c4'];
					$q = $row['d4'];
					
					$cornea2 = $row['cornea2'];
					$A_C2  = $row['A_C2'];
					$pupil2 = $row['pupil2'];
					$lence2 = $row['lence2'];
					$Vitroeus2 = $row['Vitroeus2'];
					$retina2 = $row['retina2'];
					$opticalnerve2 = $row['opticalnerve2'];
					$retina2 = $row['retina2'];
					$C_D_R2  = $row['C_D_R2'];
					$pinhole2 = $row['pinhole2'];
					$complaint2 = $row['complaint2'];
					$PD2 = $row['PD2'];
					$Pressure2 = $row['Pressure2'];
					$eyelid2 = $row['eyelid2'];
					$conj_ctive2 = $row['conj_ctive2'];
					$av = $row['V_A'];
					$glss = $row['glasses'];
					

				}
			}



		?>
		 <!--###########################################################################-->
 <div class="add-user-main-panel">
  	<form enctype="multipart/form-data"  action="addDiagnosedcodeupdate.php" method="POST">

	 <table width="669" align="center">
	 	<tr>
			<td width="122" rowspan="5"><img src="profile/<?php echo $passport; ?>" alt="Passport" width="147" height="137" /><br />
				<input id="textfield"type="hidden" name="patNo" value="<?php echo $id; ?>" />
				
		    <td width="535">Make sure you use valid information for this registration, because it is very important to this institute for future use. </td>
	 	</tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
     </table>
<hr />
	  <table width="669" align="center">

	 	<tr>
	 	  <td colspan="4" bgcolor="#000099"><h3><span class="style3">Diagnosis(Right Eye)</span> </h3></td>
 	    </tr>
	 	<tr>
			
		   <td width="130"><label for="label3">Vision</label>
	        <input name="vission" value="<?php echo $vission;?>" required type="text" id="label3" size="20" /></td>
			
			  
		  
			  <td width="100"><label for="select">Pin hole</label>
			  <select name="pinhole" id="select">
			    <option value="6/4" selected="selected">6/4</option>
			    <option value="6/5">6/5<option>
			    <option value="5/6">5/6</option>
			    <option value="6/9">6/9</option>
			    <option value="6/12">6/12</option>
			    <option value="6/18">6/18</option>
			   <option value="6/24">6/24</option>
			   <option value="6/36">6/36</option>
			   <option value="6/60">6/60</option>
			   <option value="5/60">5/60</option>
			   <option value="4/60">4/60</option>
			   <option value="3/60">3/60</option>
			   <option value="2/60">2/60</option>
			   <option value="1/60">1/60</option>
			   <option value="C.F">C.F</option>
			   <option value="HM">HM</option>
			   <option value="PL">PL</option>
			   <option value="NPL">NPL</option>

		      </select></td>
			  
			  
			  <td width="120"><label for="label">V.A</label>
	        <input name="V_A" type="text" value="<?php echo $v;?>" required id="label" size="20" /></td>
			  
		    
		    
	 	</tr>
	 </table>
<hr />
	   <table width="669" align="center">
 <td width="181"><label for="label">Glasses</label>
	        <input name="glasses" value="<?php echo $glass;?>"type="text" id="label"required size="20" /></td>
		   
		   <td width="181"><label for="label">P.D</label>
	        <input name="PD" value="<?php echo $PD;?>" type="text" id="label"required size="20" /></td>
			   
		     
			   
	 	</tr>
	  </table>
<hr />


<table width="30" border="1" align="left">
<tr>
<td colspan="4" style="text-align:center;">Auto-Refraction</td>
<tr>

<tr>
<td>S</td>
<td>C</td>
<td>AX</td>
<td>ADD</td>
</tr>
<tr>
<td>
<input name="a" type="text" value="<?php echo $a;?>"id="label2"required size="5" /></td>
<td><input name="b" type="text"value="<?php echo $b;?>" id="label2"required size="5" /></td>
<td><input name="c" type="text" value="<?php echo $c;?>"id="label2"required size="5" /></td>
<td><input name="d" type="text" value="<?php echo $d;?>" id="label2" required size="5" /></td>

</tr>
</table>
<table border="1" ">
<tr>
<td colspan="4" style="text-align:center;">Subjective Refraction</td>
<tr>
<tr align="right">
<td>S</td>
<td>C</td>
<td>AX</td>
<td>ADD</td>
</tr>
<tr>
<td>
<input name="a2" type="text" value="<?php echo $e;?>"id="label2" required size="5" /></td>
<td><input name="b2" type="text" value="<?php echo $g;?>"id="label2" required size="5" /></td>
<td><input name="c2" type="text" value="<?php echo $h;?>"id="label2" required size="5" /></td>
<td><input name="d2" type="text" value="<?php echo $i;?>"id="label2" required size="5" /></td>

</tr>
</table>
<hr/>

	 <table width="669" align="center">
		<tr>
		  <td colspan="4" bgcolor="#000099"><h3 class="style3">Left Eye </h3></td>
	   	</tr>	
		<tr>
			   <td width="130"><label for="label3">Vision</label>
	        <input name="vission2" value="<?php echo $vission2;?>"required type="text" id="label3" size="20" /></td>
			  
		  
			  <td width="100"><label for="select">Pin hole</label>
			  <select name="pinhole2" id="select">
			    <option value="6/4" selected="selected">6/4</option>
			    <option value="6/5">6/5<option>
			    <option value="5/6">5/6</option>
			    <option value="6/9">6/9</option>
			    <option value="6/12">6/12</option>
			    <option value="6/18">6/18</option>
			   <option value="6/24">6/24</option>
			   <option value="6/36">6/36</option>
			   <option value="6/60">6/60</option>
			   <option value="5/60">5/60</option>
			   <option value="4/60">4/60</option>
			   <option value="3/60">3/60</option>
			   <option value="2/60">2/60</option>
			   <option value="1/60">1/60</option>
			   <option value="C.F">C.F</option>
			   <option value="HM">HM</option>
			   <option value="PL">PL</option>
			   <option value="NPL">NPL</option>

		      </select></td>
			  
			  
			  <td width="120"><label for="label">V.A</label>
	        <input name="V_A2" type="text" value="<?php echo $av;?>" required id="label" size="20" /></td>
			  
		    
		    
	 	</tr>
	 </table>
	 <hr/>
	  <table width="669" align="center">
 <td width="181"><label for="label">Glasses</label>
	        <input name="glasses2" value="<?php echo $glass;?>"type="text" id="label"required size="20" /></td>
		   
		   <td width="181"><label for="label">P.D</label>
	        <input name="PD2" type="text" value="<?php echo $PD2;?>"id="label"required size="20" /></td>
			   
		     
			  
	 	</tr>
	  </table>
<hr />

			  
			  


<table width="30" border="1" align="left">
<tr>
<td colspan="4" style="text-align:center;">Auto-Refraction</td>
<tr>

<tr>
<td>S</td>
<td>C</td>
<td>AX</td>
<td>ADD</td>
</tr>
<tr>
<td>
<input name="a3" type="text" value="<?php echo $j;?>"id="label2"required size="5" /></td>
<td><input name="b3" type="text" value="<?php echo $k;?>"id="label2"required size="5" /></td>
<td><input name="c3" type="text" value="<?php echo $l;?>"id="label2"required size="5" /></td>
<td><input name="d3" type="text" id="label2" value="<?php echo $m;?>"required size="5" /></td>

</tr>
</table>
<table border="1">
<tr>
<td colspan="4" style="text-align:center;">Subjective Refraction</td>
<tr>
<tr align="right">
<td>S</td>
<td>C</td>
<td>AX</td>
<td>ADD</td>
</tr>
<tr>
<td>
<input name="a4" value="<?php echo $n;?>"type="text" id="label2" size="5" required/></td>
<td><input name="b4"value="<?php echo $o;?>" type="text" id="label2" size="5" required/></td>
<td><input name="c4"value="<?php echo $p;?>" type="text" id="label2" size="5" required/></td>
<td><input name="d4" value="<?php echo $q;?>"type="text" id="label2" size="5"required /></td>

</tr>
</table>
<hr/>

 <table width="669" align="center">
		<tr>
		  <td bgcolor="#000000"><span class="style3">Before submitting, make sure that all the information you used is correct</span></td>
	    </tr>
	 </table>
<hr />
	  <table width="669" align="center">
		<tr>
		  <td colspan="2"><label for="Submit"></label>
	      <input type="submit" name="submit" value="Submit" id="Submit" /></td>
		  <td width="482"><label for="label16"></label>
	      <input type="reset" name="reset" value="Reset" id="label16" /></td>
        </tr>
	 </table>


    </form>
  </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
