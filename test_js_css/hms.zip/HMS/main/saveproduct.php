<?php
require_once('../auth.php');
include('../configuration.php');
$a = $_POST['code'];
$b = $_POST['name'];
$c = $_POST['cost'];
$d = $_POST['price'];
$e = $_POST['supplier'];
$f = $_POST['qty'];
$g = date('Y-m-d');
$h = $_POST['expiryDate'];
// query
$sql = "INSERT INTO products (product_code,product_name,cost,price,supplier,qty,dateIn,expiryDate) VALUES (:a,:b,:c,:d,:e,:f,:g,:h)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':e'=>$e,':f'=>$f, ':g'=>$g, ':h'=>$h));
header("location: viewproducts.php");


?>