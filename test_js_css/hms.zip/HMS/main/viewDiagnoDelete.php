<?php
	include('../configuration.php');

  if(isset($_GET['patNo'])!="")
  {
  $delete=$_GET['patNo'];
  $delete=mysql_query("Update patients SET verify='new'  WHERE  No='$delete'");
  $delete=mysql_query("DELETE FROM diagnosis WHERE  patNo='$delete'");
  if($delete)
  {
     header("Location:viewDiagno.php");
  }
  else
  {
      echo mysql_error();
  }
  }
  
?>