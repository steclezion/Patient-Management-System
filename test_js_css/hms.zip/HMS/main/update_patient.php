<?php
	require_once('../auth.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Vine eye center manage</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />

<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
-->
</style>
</head>

<body>
<div class="add-container">
  <div class="banner-div">
    <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">
 <table width="669" align="center">
        <tr>
          <td height="20" colspan="2"><h2 align="center"><span class="style1"> Welcome to Vine eye center management system </span></h2></td>
        </tr>
        <tr>
          <td width="417">
		  <a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  <a href="add_patient.php?action=add"><button>New Patient</button></a>&nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;

	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>
		  </td>

    </table>
  </div>
  <!--###########################################################################-->
  <?php
			
			require('../configuration.php');

			$id = $_REQUEST['updateid'];

			$qry = mysql_query("select * from patients where No = '$id'");
			if(!$qry){echo mysql_error();}else{

				while($row = mysql_fetch_array($qry)){
					$id = $row['No'];
					$passport = $row['pport'];
					$title = $row['title'];
					$firstname = $row['fname'];
					$middlename = $row['mname'];
					$lastname = $row['lname'];
					$gender = $row['gender'];
					$dob = $row['dob'];
					$age = $row['age'];
					$tel = $row['tel'];
					$address = $row['address'];
					$dEntry = $row['dEntry'];

				}
			}



		?>
 <div class="add-user-main-panel">
 	<form enctype="multipart/form-data" name="newStaffForm" action="update_patient_code.php?id=<?php echo $id; ?>" method="POST">

	 <table width="669" align="center">
	 	<tr>
			<td width="122" rowspan="5"><img src="profile/<?php echo $passport; ?>" alt="Passport" width="147" height="137" /><br />
				<input id="textfield"type="hidden" name="MAX_FILE_SIZE" value="1000000" />
				<input id="textfield"name="uploadedfile" required type="file" />		    </td>
		    <td width="535">Make sure you use valid information for this registration, because it is very important to this company for future use. </td>
	 	</tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
     </table>
<hr />
	 <table width="669" align="center">

	 	<tr>
	 	  <td colspan="4" bgcolor="#000099"><h3><span class="style3">Patient Detail information</span> </h3></td>
 	    </tr>
	 	<tr>
			<td width="96"><label for="select">Title</label>
			  <select name="title" id="select">
			    <option selected="seleted"><?php echo $title; ?></option>
			    <option value="Mr.">Mr.</option>
			    <option value="Mrs.">Mrs.</option>
			    <option value="Dr.">Dr.</option>
			    <option value="Eng.">Eng.</option>
			    <option value="Prof.">Prof.</option>
			    <option value="Alh">Alh.</option>
			    <option value="Haj.">Haj.</option>
		      </select>		    </td>
		    <td width="181"><label for="label">First Name</label>
	        <input name="fname" type="text" id="label" required size="10" value="<?php echo $firstname; ?>" /></td>
		    <td width="191"><label for="label2">Middle Name</label>
	        <input name="mname" type="text" id="label2" size="10" value="<?php echo $middlename; ?>" /></td>
		    <td width="181"><label for="label3">Last Name</label>
	        <input name="lname" type="text" id="label3" size="10" value="<?php echo $lastname; ?>" /></td>
	 	</tr>
	  </table>
<hr />
		<table width="669" align="center">
		<tr>
		  <td colspan="2"><label for="label4">Gender</label>
            <select name="gender" id="label4">
			  <option selected="seleted"><?php echo $gender; ?></option>
			  <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select></td>
	      <td width="250"><label for="textfield">Date of Birth</label>
          <input name="dob" type="text" id="textfield" size="20" value="<?php echo $dob; ?>" /></td>
	      <td width="276"><label for="label5">Age</label>
          <input type="text" name="age" id="label5" value="<?php echo $age; ?>" /></td>
		</tr>

	 </table>
<hr />
	 <table width="669" align="center">
		<tr>
		  <td colspan="2"><label for="label6">Contact</label>
	      <input type="text" name="tel" id="label6" value="0<?php echo $tel; ?>" /></td>
		  <td width="250"><label for="label6">Address</label>
	      <input type="text" name="address" id="label6" value="<?php echo $address; ?>" /></td>
		 
	    
		</tr>
	 </table>
<hr />
	  <table width="669" align="center">
		<tr>
		  <td><label for="label9">Date Entry</label>
	      <input name="dEntry" type="text" id="label9" size="50" value="<?php echo $dEntry; ?>"/>	</td>
	    </tr>
	 </table>
<hr />
	
	
	  <table width="669" align="center">
		<tr>
		  <td bgcolor="#999900"><span class="style3">Before submitting, make sure that all the information you used is correct</span></td>
	    </tr>
	 </table>
<hr />
	  <table width="669" align="center">
		<tr>
		  <td colspan="2"><label for="Submit"></label>
	      <input type="submit" name="submit" value="Submit" id="Submit" /></td>
		  <td width="482"><label for="label16"></label>
	      <input type="reset" name="reset" value="Reset" id="label16" /></td>
        </tr>
	 </table>


    </form>
 </div>
 	<div class="footer-div"></div>
</div>
</body>
</html>
