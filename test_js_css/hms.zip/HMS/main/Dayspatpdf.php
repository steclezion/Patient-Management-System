<?php
	require_once('../auth.php');
	require('../configuration.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Vine eye center management system</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="../style.css" rel="stylesheet" type="text/css" />

<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
.style19 {font-size: 24px; font-family: Geneva, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
					<SCRIPT TYPE="text/javascript"> 
 
var message="Sorry, right-click has been disabled"; 

function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 

</SCRIPT>

    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

      <table width="669" align="center">
        <tr>
          <td height="20" colspan="2"><h2 align="center"><span class="style1"> Welcome to view diagnosis</span></h2></td>
        </tr>
        <tr>
          <td width="417">
		 <a href="index.php?action=index"><button>Home</button></a> &nbsp;
		 <a href="viewpat.php?action=view"><button>View Patients</button></a> &nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;

	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
       
        </tr>
    </table>

  <!--###########################################################################-->
 <div class="add-user-main-panel">
<?php
include("pdf/class.ezpdf.php");
// create the quer to be displayed
$a=$_POST['from'];
$b=$_POST['to'];
$query = "SELECT  * FROM patients WHERE  dEntry BETWEEN '$a' AND '$b'";
// check if the query returned some results
if(mysql_num_rows(mysql_query($query))<1) { echo "No results were found"; }
//start the pdf staff
$pdf =& new Cezpdf();
$pdf->selectFont('pdf/fonts/Helvetica');
//--------------------------------------------------
// initialize the array
$data = array();
// do the SQL query
$result = mysql_query($query) or die (mysql_error());
// step through the result set, populating the array, note that this could
//also have been written:
// while($data[] = mysql_fetch_assoc($result)) {}
while($data[] = mysql_fetch_array($result, MYSQL_ASSOC)) {}
// make the table
$pdf->ezTable($data,array('No'=>'Patient No','fname'=>'First Name','lname'=>'Last Name','age'=>'Age','gender' =>'Gender','tel'=>'Phone','address'=>'Address')," Patients Report ");
// do the output, this is my standard testing output code, adding ?d=1
// to the url puts the pdf code to the screen in raw form, good for
//checking
// for parse errors before you actually try to generate the pdf file.
if (isset($d) && $d){
$pdfcode = $pdf->output(1);
$pdfcode = str_replace("\n","\n<br>",htmlspecialchars($pdfcode));
echo '<html><body>';
echo trim($pdfcode);
echo '</body></html>';
} else {
$pdf->stream();
}
?>
</div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
