<?php
include('../configuration.php');	
$id=$_GET['No'];
	
	//edit qty
	$sql = mysql_query("UPDATE treatment 
			SET received='received'
			WHERE pNo='$id'") or mysql_error();
			$sql2 = mysql_query("UPDATE procedurers 
			SET status='confirmed'
			WHERE paNo='$id'") or mysql_error();
	
	//header("location: recommendations.php");
?>