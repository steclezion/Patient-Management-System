<?php
	require_once('../auth.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>vine clinic</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="tcal.css" />
<script type="text/javascript" src="tcal.js"></script>
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
-->
</style>
</head>
		<SCRIPT TYPE="text/javascript"> 
 
var message="Sorry, right-click has been disabled"; 

function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 

</SCRIPT>
<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
			<script type="text/javascript">

function getAge(){
    var dob = document.getElementById('date').value;
    dob = new Date(dob);
    var today = new Date();
    var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
    document.getElementById('age').value=age;
}

</script>
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

       <table width="669" align="center">
        <tr>
          <td height="43" colspan="2"><h2 align="center"><span class="style1"> Welcome to patient's Form </span></h2></td>
        </tr>
        <tr>
          <td width="417">
		  	<a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  <a href="add_patient.php?action=add"><button>New Patient</button></a>&nbsp;
		  <a href="viewpat.php?action=view"><button>View</button></a>&nbsp;

	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
          <td width="240">
		  	<form name="searchForm" action="search_index_patient.php" method="POST">
		  		<input type="textfield" name="search" placeholder="Search patient" />
				<button type="submit">Search</button>
		  	</form>
		  </td>
        </tr>
    </table>
  </div>
  <!--###########################################################################-->
 <div class="add-user-main-panel">
 	<form enctype="multipart/form-data"  action="add_patient_code.php" method="POST">

	 <table width="669" align="center">
	 	<tr>
			<td width="122" rowspan="5"><img alt="Passport" width="147" height="137" /><br />
				<input id="textfield"type="hidden" name="MAX_FILE_SIZE" value="1000000" />
				<input id="textfield"name="uploadedfile" require type="file" required/>		    </td>
		    <td width="535">Make sure you use valid information for this registration, because it is very important to this company for future use. </td>
	 	</tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
     </table>
<hr />
	 <table width="669" align="center">

	 	<tr>
	 	  <td colspan="4" bgcolor="#000099"><h3><span class="style3">Patient Detail information</span> </h3></td>
 	    </tr>
	 	<tr>
			<td width="96"><label for="select">Title</label>
			  <select name="title" id="select">
			    <option value="Mr." selected="selected">Mr.</option>
			    <option value="Mrs.">Mrs.</option>
			    <option value="Dr.">Dr.</option>
			    <option value="Eng.">Eng.</option>
			    <option value="Prof.">Prof.</option>
			    <option value="Alh">Alh.</option>
			    <option value="Haj.">Haj.</option>
		      </select>		    </td>
		    <td width="181"><label for="label">Patient No</label>
	        <input name="No" type="text" id="label" value="<?php echo date("Y-m-d");?>"required/ size="15" /></td>
		    <td width="191"><label for="label2">First Name</label>
	        <input name="fname" type="text" id="label2" size="10" /></td>
		    <td width="191"><label for="label2">Middle Name</label>
	        <input name="mname" type="text" id="label2" size="10" /></td>
	 	</tr>
	  </table>
<hr />
		<table width="669" align="center">
		<tr>
		<td width="181"><label for="label3">Last Name</label>
	        <input name="lname" type="text" id="label3" size="10" /></td>
			
		  <td colspan="2"><label for="label4">Gender</label>
            <select name="gender" id="label4">
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select></td>
	      <td width="250"><label for="textfield">Date of Birth</label>
          <input name="dob" type="text" id="date" onblur="getAge();" class="tcal" size="20" /></td>
	     
		</tr>

	 </table>
<hr />
	 <table width="669" align="center">
		<tr>
	      <td width="276"><label for="label5">Age</label>
          <input type="text" id="age" name="age" class="form-control"  /></td>
		  <td width="181"><label for="label3">Contact </label>
	        <input name="tel" type="text" id="label3" size="10" /></td>
		    <td width="191"><label for="label2">Address</label>
	        <input name="address" type="text" id="label2" size="15" /></td>
		    
		
	      
		</tr>
	 </table>
<hr />
	  <table width="669" align="center">
		<tr>
		  <td><label for="label9"> Date Entry</label>
	      <input name="dEntry" type="text" class="tcal" id="label9" size="25" />	</td>
	    </tr>
	 </table>


<hr />
	  <table width="669" align="center">
		<tr>
		  <td bgcolor="#000000"><span class="style3">Before submitting, make sure that all the information you used are correct</span></td>
	    </tr>
	 </table>
<hr />
	  <table width="669" align="center">
		<tr>
		  <td colspan="2"><label for="Submit"></label>
	      <input type="submit" name="submit" value="Submit" id="Submit" /></td>
		  <td width="482"><label for="label16"></label>
	      <input type="reset" name="reset" value="Reset" id="label16" /></td>
        </tr>
	 </table>


    </form>
  </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
