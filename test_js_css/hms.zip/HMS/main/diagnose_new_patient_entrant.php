<?php
	require_once('../auth.php');
				require('../configuration.php');


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>vine eye center</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="../style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="tcal.css" />
<script type="text/javascript" src="tcal.js"></script>

<!--sa poip up-->
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>

<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
-->
</style>
</head>

<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
			<script type="text/javascript">

function getAge(){
    var dob = document.getElementById('date').value;
    dob = new Date(dob);
    var today = new Date();
    var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
    document.getElementById('age').value=age;
}

</script>
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

       <table width="669" align="center">
        <tr>
          <td height="43" colspan="2"><h2 align="center"><span class="style1"> Welcome to patient's Form </span></h2></td>
        </tr>
        <tr>
           <td width="417">
		  <a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  		  <a href="viewDiagno_techn.php?action=add"><button>View Diagnosed</button></a>&nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;
	
	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
         
    </table>

  </div>
  <?php
			

			$id = $_REQUEST['viewid'];

			$qry = mysql_query("select * from patients where No = '$id' AND verify='new' ");
			if(!$qry){echo mysql_error();}else{

				while($row = mysql_fetch_array($qry)){
					$id = $row['No'];
					$passport = $row['pport'];
					
				}
			}



		?>
  <!--###########################################################################-->
 <div class="add-user-main-panel">
 	<form enctype="multipart/form-data"  action="addDiagnosedcodenew.php" method="POST">

	 <table width="669" align="center">
	 	<tr>
			<td width="122" rowspan="5"><img src="profile/<?php echo $passport; ?>" alt="Passport" width="147" height="137" /><br />
				<input id="textfield"type="hidden" name="aaa" value="<?php echo $id; ?>" />
				
		    <td width="535">Make sure you use valid information for this registration, because it is very important to this institute for future use. </td>
	 	</tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
     </table>
<hr />
	  <table width="669" align="center">

	 	<tr>
	 	  <td colspan="4" bgcolor="#000099"><h3><span class="style3">Diagnosis(Right Eye)</span> </h3></td>
 	  
	 	<tr>
			
		   
		 
			   <td width="130"><label for="label3">Vision</label>
	        <input name="vission" required type="text" id="label3" size="20" /></td>
			
			  
		  
			  <td width="100"><label for="select">Pin hole</label>
			  <select name="pinhole" id="select">
			    <option value="6/4" selected="selected">6/4</option>
			    <option value="6/5">6/5<option>
			    <option value="5/6">5/6</option>
			    <option value="6/9">6/9</option>
			    <option value="6/12">6/12</option>
			    <option value="6/18">6/18</option>
			   <option value="6/24">6/24</option>
			   <option value="6/36">6/36</option>
			   <option value="6/60">6/60</option>
			   <option value="5/60">5/60</option>
			   <option value="4/60">4/60</option>
			   <option value="3/60">3/60</option>
			   <option value="2/60">2/60</option>
			   <option value="1/60">1/60</option>
			   <option value="C.F">C.F</option>
			   <option value="HM">HM</option>
			   <option value="PL">PL</option>
			   <option value="NPL">NPL</option>

		      </select></td>
			  
			  
			  <td width="120"><label for="label">V.A</label>
	        <input name="V_A" type="text" required id="label" size="20" /></td>
			  
		    
		    
	 	</tr>
	 </table>
<hr />
	   <table width="669" align="center">
 <td width="181"><label for="label">Glasses</label>
	        <input name="glasses" type="text" id="label"required size="20" /></td>
		   
		   <td width="181"><label for="label">P.D</label>
	        <input name="PD" type="text" id="label"required size="20" /></td>
			   
		     
			   
	 	</tr>
	  </table>
<hr />


<table width="30" border="1" align="left">
<tr>
<td colspan="4" style="text-align:center;">Auto-Refraction</td>
<tr>

<tr>
<td>S</td>
<td>C</td>
<td>AX</td>
<td>ADD</td>
</tr>
<tr>
<td>
<input name="a" type="text" id="label2"required size="5" /></td>
<td><input name="b" type="text" id="label2"required size="5" /></td>
<td><input name="c" type="text" id="label2"required size="5" /></td>
<td><input name="d" type="text" id="label2" required size="5" /></td>

</tr>
</table>
<table border="1" ">
<tr>
<td colspan="4" style="text-align:center;">Subjective Refraction</td>
<tr>
<tr align="right">
<td>S</td>
<td>C</td>
<td>AX</td>
<td>ADD</td>
</tr>
<tr>
<td>
<input name="a2" type="text" id="label2" required size="5" /></td>
<td><input name="b2" type="text" id="label2" required size="5" /></td>
<td><input name="c2" type="text" id="label2" required size="5" /></td>
<td><input name="d2" type="text" id="label2" required size="5" /></td>

</tr>
</table>
<hr/>

	 <table width="669" align="center">
		<tr>
		  <td colspan="4" bgcolor="#000099"><h3 class="style3">Left Eye </h3></td>
	   	</tr>	
		<tr>
			   <td width="130"><label for="label3">Vision</label>
	        <input name="vission2" required type="text" id="label3" size="20" /></td>
			  
		  
			  <td width="100"><label for="select">Pin hole</label>
			  <select name="pinhole2" id="select">
			    <option value="6/4" selected="selected">6/4</option>
			    <option value="6/5">6/5<option>
			    <option value="5/6">5/6</option>
			    <option value="6/9">6/9</option>
			    <option value="6/12">6/12</option>
			    <option value="6/18">6/18</option>
			   <option value="6/24">6/24</option>
			   <option value="6/36">6/36</option>
			   <option value="6/60">6/60</option>
			   <option value="5/60">5/60</option>
			   <option value="4/60">4/60</option>
			   <option value="3/60">3/60</option>
			   <option value="2/60">2/60</option>
			   <option value="1/60">1/60</option>
			   <option value="C.F">C.F</option>
			   <option value="HM">HM</option>
			   <option value="PL">PL</option>
			   <option value="NPL">NPL</option>

		      </select></td>
			  
			  
			  <td width="120"><label for="label">V.A</label>
	        <input name="V_A2" type="text" required id="label" size="20" /></td>
			  
		    
		    
	 	</tr>
	 </table>
	 <hr/>
	  <table width="669" align="center">
 <td width="181"><label for="label">Glasses</label>
	        <input name="glasses2" type="text" id="label"required size="20" /></td>
		   
		   <td width="181"><label for="label">P.D</label>
	        <input name="PD2" type="text" id="label"required size="20" /></td>
			   
		     
			  
	 	</tr>
	  </table>
<hr />

			  
			  


<table width="30" border="1" align="left">
<tr>
<td colspan="4" style="text-align:center;">Auto-Refraction</td>
<tr>

<tr>
<td>S</td>
<td>C</td>
<td>AX</td>
<td>ADD</td>
</tr>
<tr>
<td>
<input name="a3" type="text" id="label2"required size="5" /></td>
<td><input name="b3" type="text" id="label2"required size="5" /></td>
<td><input name="c3" type="text" id="label2"required size="5" /></td>
<td><input name="d3" type="text" id="label2" required size="5" /></td>

</tr>
</table>
<table border="1">
<tr>
<td colspan="4" style="text-align:center;">Subjective Refraction</td>
<tr>
<tr align="right">
<td>S</td>
<td>C</td>
<td>AX</td>
<td>ADD</td>
</tr>
<tr>
<td>
<input name="a4" type="text" id="label2" size="5" required/></td>
<td><input name="b4" type="text" id="label2" size="5" required/></td>
<td><input name="c4" type="text" id="label2" size="5" required/></td>
<td><input name="d4" type="text" id="label2" size="5"required /></td>

</tr>
</table>
<hr/>

 <table width="669" align="center">
		<tr>
		  <td bgcolor="#000000"><span class="style3">Before submitting, make sure that all the information you used is correct</span></td>
	    </tr>
	 </table>
<hr />
	  <table width="669" align="center">
		<tr>
		  <td colspan="2"><label for="Submit"></label>
	      <input type="submit" name="submit" value="Submit" id="Submit" /></td>
		  <td width="482"><label for="label16"></label>
	      <input type="reset" name="reset" value="Reset" id="label16" /></td>
        </tr>
	 </table>


    </form>
  </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
