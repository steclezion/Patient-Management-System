





<?php
	require_once('../auth.php');
require('../configuration.php');
?>
<?php
$No = $_POST['pNo'];
$checkbox1 = $_POST['medicineName'];
$patno = $_POST['pNo'];
$dd = date('m/d/y');
for ($i=0; $i<sizeof($checkbox1);$i++) {
	$query="INSERT INTO  treatment (medicineName,pNo,received,date) VALUES ('".$checkbox1[$i]."','".$patno."','not-Yet','".$dd."')";
	mysql_query($query) or die (mysql_error());
}


			if($query){

				echo ' treatment for a patient added successfully, Please wait... ';

				echo '<script type="text/javascript">

						var myVar=setInterval(function(){myTimer()},2000);

				function myTimer()
				{
					window.location="viewDiagno.php";

				}
			</script>';
			}else {	echo mysql_error();	}

	
	

?>