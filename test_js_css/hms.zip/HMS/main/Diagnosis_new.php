<?php
	require_once('../auth.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>vine eye center</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="tcal.css" />
<script type="text/javascript" src="tcal.js"></script>

<!--sa poip up-->
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>

<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
-->
</style>
</head>

<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
			<script type="text/javascript">

function getAge(){
    var dob = document.getElementById('date').value;
    dob = new Date(dob);
    var today = new Date();
    var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
    document.getElementById('age').value=age;
}

</script>
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

       <table width="669" align="center">
        <tr>
          <td height="43" colspan="2"><h2 align="center"><span class="style1">Doctor's diagnosis Form </span></h2></td>
        </tr>
        <tr>
           <td width="417">
		  <a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  		  <a href="viewDiagno.php?action=add"><button>View Diagnosed</button></a>&nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;
	
	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
         
    </table>

  </div>
  <?php
			
			require('../configuration.php');

			$id = $_REQUEST['viewid'];

			$qry = mysql_query("select * from diagnosis d,patients p where d.patNo=p.No AND d.patNo = '$id'");
			if(!$qry){echo mysql_error();}else{

				while($row = mysql_fetch_array($qry)){
					$id = $row['No'];
					$passport = $row['pport'];
					
				}
			}



		?>
  <!--###########################################################################-->
 <div class="add-user-main-panel">
 	<form enctype="multipart/form-data"  action="addDiagnosedcode.php" method="POST">

	 <table width="669" align="center">
	 	<tr>
			<td width="122" rowspan="5"><img src="profile/<?php echo $passport; ?>" alt="Passport" width="147" height="137" /><br />
				<input id="textfield"type="hidden" name="patNo" value="<?php echo $id; ?>" />
				
		    <td width="535">Make sure you use valid information for this registration, because it is very important to this institute for future use. </td>
	 	</tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
     </table>
<hr />
	 <table width="669" align="center">

	 	<tr>
	 	  <td colspan="4" bgcolor="#000099"><h3><span class="style3">Diagnosis(Right Eye)</span> </h3></td>
 	    </tr>
	 	<tr>
		<td width="110"><label for="label">I.O.P</label>
	        <input name="iop" type="text" required id="label" size="5" /></td>
			  
		     <td width="160"><label for="label7">Complaint</label>
			  <select name="complaint" id="label7">
			    <option value="poor vision" selected="selected">Poor vision</option>
			    <option value="red eye" selected="selected">Red eye</option>
			    <option value="pawn">Pain</option>
			    <option value="itching">Itching</option>
			    <option value="tearing">Tearing</option>
			    <option value="Dry">Dry</option>
			    <option value="discharge growth">Discharge growth</option>
			    <option value="foreign body">Foreign body</option>
			    <option value="Normal">Normal</option>
			   
		      </select></td>
			  			  <td width="140"><label for="label7">Eye lid</label>
			  <select name="eyelid" id="label7">
			    <option value="swollen" selected="selected">Swollen</option>
			    <option value="growth" selected="selected">Growth</option>
			    <option value="tear" selected="selected">Tear</option>
			    <option value="trichiasis">Trichiasis</option>
			    <option value="entropion">entropion</option>
			    <option value="lagophthalnos">lagophthalnos</option>
			    <option value="Eccymosis">Eccymosis</option>
			    <option value="Normal">Normal</option>

			   
		      </select></td>
			  

		   			  <td width="130"><label for="label7">Conjunctiva</label>
			  <select name="conj_ctive" id="label7">
			    <option value="red" selected="selected">Red</option>
			    <option value="injection" selected="selected">Injection</option>
			    <option value="discharge">Discharge</option>
			    <option value="chemosis">Chemosis</option>
			    <option value="pterygium">Pterygium</option>
			    <option value="pengicular">pengicular</option>
			    <option value="tarsal-reaction">Tarsal-reaction</option>
			    <option value="limbal reaction">Limbal Reaction</option>
			    <option value="Normal">Normal</option>

			   
		      </select></td>
		 

	 	</tr>
	  </table>

<hr />


<table width="669" align="center">


			  			<td width="100"><label for="select">Cornea</label>
			  <select name="cornea" id="select">
			    <option value="dry" selected="selected">Ulcer</option>
			    <option value="F.B">F.B</option>
			    <option value="Scar">Scar</option>
			    <option value="Edema">Edema</option>
			    <option value="K.PS">K.Ps</option>
			    <option value="Perforation">Perforation</option>
			   <option value="Normal">Normal</option>

		      </select></td>
			   
			 <td width="96"><label for="select">A.C</label>
			  <select name="A_C" id="select">
			    <option value="Cells" selected="selected">Cells</option>
			    <option value="Flare" selected="selected">Ulcer</option>
			    <option value="Hypopyon">Hypopyon</option>
			    <option value="Hyphema">Hyphema</option>
			    <option value="Fibrin">Fibrin</option>
			    <option value="Normal">Normal</option>
			   
		      </select></td>
			  
			  
			  
			  <td width="120"><label for="select">pupil</label>
			  <select name="pupil" id="select">
			    <option value="Irregular" selected="selected">Irregular</option>
			    <option value="Synichea" selected="selected">Synichea</option>
			    <option value="R.A.P.D">R.A.P.D</option>
			    <option value="Fixed-dialated">Fixed-dialated</option>
			    <option value="Fixed-Constricted">Fixed-Constricted</option>
			    <option value="P.E.X">P.E.X</option>
			    <option value="Atrophy">Atrophy</option>
			    <option value="Normal">Normal</option>

			   
		      </select></td>
			  
			  <td width="96"><label for="select">Lens</label>
			  <select name="lence" id="select">
			    <option value="contaract" selected="selected">contaract</option>
			    <option value="P.C.O" selected="selected">P.C.O</option>
			    <option value="aphakic">Aphakic</option>
			    <option value="Pseudophakic">Pseudophakic</option>
			    <option value="Normal">Normal</option>

			   
		      </select></td>
			   
		
			 

		    
		    
	 	</tr>
	  </table>
	 <hr/>
	 <table width="669" align="center">

			  <td width="130"><label for="select">Vitreous</label>
			  <select name="Vitroeus" id="select">
			    <option value="cells" selected="selected">Cells</option>
			    <option value="flayer">Flare</option>
			    <option value="astavoid">Astavoid</option>
			    <option value="hyalosis">Hyalosis</option>
			    <option value="synchysiscintillans">K.Ps</option>
			    <option value="hemorrage">Hemorrage</option>
			   <option value="Normal">Normal</option>

		      </select></td>
			  
			  <td width="150"><label for="select">Retina</label>
			  <select name="retina" id="select">
			    <option value="rdamd" selected="selected">Rdamd</option>
			    <option value="de torched" selected="selected">De torched</option>
			    <option value="haemorrhage" selected="selected">Haemorrhage</option>
			    <option value="csme" selected="selected">Csme</option>
			    <option value="exudate">Exudate</option>
			    <option value="cotton-wool">Cotton-wool</option>
			    <option value="hemor">Hemor</option>
			    <option value="tigroid">Tigroid</option>
			    <option value="pale">Pale</option>
			    <option value="edema">Edema</option>
			    <option value="New Vessel">New vessel</option>
			    <option value="Normal">Normal</option>
			   
		      </select></td>
			   
			
			  
			  
			  <td width="130"><label for="label2">Optic nerve</label>
			  <select name="opticalnerve" id="label2">
			    <option value="Pale" selected="selected">Pale</option>
			    <option value="cupped" selected="selected">Cupped</option>
			    <option value="edema">Edema</option>
			    <option value="Atrophy">Atrophy</option>
			    <option value="Normal">Normal</option>

			   
		      </select></td>
			  
			  
			  <td width="100"><label for="label3">C.D.R</label>
	        <input name="C_D_R" type="text" id="label3" size="5" /></td>
			
		   
	 	</tr>
	  </table>
	  <hr/>
	   <table width="669" align="center">
	  <tr>
	  <td width="90"><label for="label">Pressure</label>
	        <input name="Pressure" type="text" required id="label" size="5" /></td>
	  
   <td width="70"><label for="label">Other findings</label>
	        <input name="others" type="text" id="label"required size="20" /></td>
			
			<td width="70"><label for="label">Disease</label>
	        <input name="desease" type="text" id="label"required size="15" /></td>
			
	</tr>
	 </table>
<hr/>
	 <table width="669" align="center">
		<tr>
		  <td colspan="4" bgcolor="#000099"><h3 class="style3">Left Eye </h3></td>
	    </tr>
		<tr>
		<td width="110"><label for="label">I.O.P</label>
	        <input name="iop2" type="text" required id="label" size="5" /></td>
			
			<td width="160"><label for="label7">Complaint</label>
			  <select name="complaint2" id="label7">
			    <option value="poor vision" selected="selected">Poor vision</option>
			    <option value="red eye" selected="selected">Red eye</option>
			    <option value="pain">Pain</option>
			    <option value="itching">Itching</option>
			    <option value="tearing">Tearing</option>
			    <option value="Dry">Dry</option>
			    <option value="discharge growth">Discharge growth</option>
			    <option value="foreign body">Foreign body</option>
			    <option value="Normal">Normal</option>

			   
		      </select></td>
			  
			  
		   <td width="130"><label for="label7">Eye lid</label>
			  <select name="eyelid2" id="label7">
			     <option value="swollen" selected="selected">Swollen</option>
			    <option value="growth" selected="selected">Growth</option>
			    <option value="tear" selected="selected">Tear</option>
			    <option value="trichiasis">Trichiasis</option>
			    <option value="entropion">entropion</option>
			    <option value="lagophthalnos">lagophthalnos</option>
			    <option value="Eccymosis">Eccymosis</option>
			    <option value="Normal">Normal</option>

		      </select></td>
		   
			   
		      </select></td>
			  <td width="160"><label for="label7">Conjunctive</label>
			  <select name="conj_ctive2" id="label7">
			    <option value="red" selected="selected">Red</option>
			    <option value="injection" selected="selected">Injection</option>
			    <option value="discharge">Discharge</option>
			    <option value="chemosis">Chemosis</option>
			    <option value="pterygium">Pterygium</option>
			    <option value="pengicular">Pengicular</option>
			    <option value="Limbal reaction">Limbal reaction</option>
			    <option value="tarsal-reaction">Tarsal-reaction</option>
			    <option value="Normal">Normal</option>

			  
		    
		    
	 	</tr>
	  </table>
<hr />


<table width="669" align="center">


			<td width="100"><label for="select">Cornea</label>
			  <select name="cornea2" id="select">
			    <option value="dry" selected="selected">Ulcer</option>
			    <option value="F.B">F.B</option>
			    <option value="Scar">Scar</option>
			    <option value="Edema">Edema</option>
			    <option value="K.PS">K.Ps</option>
			    <option value="Perforation">Perforation</option>
			   <option value="Normal">Normal</option>

		      </select></td>
			   
			 <td width="96"><label for="select">A.C</label>
			  <select name="A_C2" id="select">
			    <option value="Cells" selected="selected">Cells</option>
			    <option value="Flare" selected="selected">Ulcer</option>
			    <option value="Hypopyon">Hypopyon</option>
			    <option value="Hyphema">Hyphema</option>
			    <option value="Fibrin">Fibrin</option>
			    <option value="Normal">Normal</option>
			   
		      </select></td>
			  
			  
			  
			  <td width="120"><label for="select">pupil</label>
			  <select name="pupil2" id="select">
			    <option value="Irregular" selected="selected">Irregular</option>
			    <option value="Synichea" selected="selected">Synichea</option>
			    <option value="R.A.P.D">R.A.P.D</option>
			    <option value="Fixed-dialated">Fixed-dialated</option>
			    <option value="Fixed-Constricted">Fixed-Constricted</option>
			    <option value="P.E.X">P.E.X</option>
			    <option value="Atrophy">Atrophy</option>
			    <option value="Normal">Normal</option>

			   
		      </select></td>
			  
			  <td width="96"><label for="select">Lens</label>
			  <select name="lence2" id="select">
			    <option value="contaract" selected="selected">contaract</option>
			    <option value="P.C.O" selected="selected">P.C.O</option>
			    <option value="aphakic">Aphakic</option>
			    <option value="Pseudophakic">Pseudophakic</option>
			    <option value="Normal">Normal</option>

			   
		      </select></td>
			   
		
	 	</tr>


	  </table>
<hr />
<table width="669" align="center">

			  <td width="130"><label for="select">Vitreous</label>
			  <select name="Vitroeus2" id="select">
			    <option value="cells" selected="selected">Cells</option>
			    <option value="flayer">Flare</option>
			    <option value="astavoid">Astavoid</option>
			    <option value="hyalosis">Hyalosis</option>
			    <option value="synchysiscintillans">K.Ps</option>
			    <option value="hemorrage">Hemorrage</option>
			   <option value="Normal">Normal</option>

		      </select></td>
			  
			  <td width="150"><label for="select">Retina</label>
			  <select name="retina2" id="select">
			    <option value="rdamd" selected="selected">Rdamd</option>
			    <option value="de torched" selected="selected">De torched</option>
			    <option value="haemorrhage" selected="selected">Haemorrhage</option>
			    <option value="csme" selected="selected">Csme</option>
			    <option value="exudate">Exudate</option>
			    <option value="cotton-wool">Cotton-wool</option>
			    <option value="hemor">Hemor</option>
			    <option value="tigroid">Tigroid</option>
			    <option value="pale">Pale</option>
			    <option value="edema">Edema</option>
			    <option value="New Vessel">New vessel</option>
			    <option value="Normal">Normal</option>
			   
		      </select></td>
			   
			
			  
			  
			  <td width="130"><label for="label2">Optic nerve</label>
			  <select name="opticalnerve2" id="label2">
			    <option value="Pale" selected="selected">Pale</option>
			    <option value="cupped" selected="selected">Cupped</option>
			    <option value="edema">Edema</option>
			    <option value="Atrophy">Atrophy</option>
			    <option value="Normal">Normal</option>

			   
		      </select></td>
			  
			  
			  <td width="100"><label for="label3">C.D.R</label>
	        <input name="C_D_R2" type="text" id="label3" size="5" /></td>
			
		   
	 	</tr>
	  </table>
	  <hr/>
 <table width="669" align="center">
	  <tr>
	  <td width="90"><label for="label">Pressure</label>
	        <input name="Pressure2" type="text" required id="label" size="5" /></td>
	  
   <td width="70"><label for="label">Other findings</label>
	        <input name="others2" type="text" id="label"required size="20" /></td>
			
			<td width="70"><label for="label">Disease</label>
	        <input name="desease2" type="text" id="label"required size="15" /></td>
			
	</tr>
	 </table>
<hr/>
 <table width="669" align="center">
		<tr>
		  <td bgcolor="#000000"><span class="style3">Before submitting, make sure that all the information you used is correct</span></td>
	    </tr>
	 </table>
<hr />
	  <table width="669" align="center">
		<tr>
		  <td colspan="2"><label for="Submit"></label>
	      <input type="submit" name="submit" value="Submit" id="Submit" /></td>
        </tr>
	 </table>


    </form>
  </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
