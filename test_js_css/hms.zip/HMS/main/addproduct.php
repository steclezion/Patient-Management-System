<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="saveproduct.php" method="post">
<div id="ac">
<span>Product Code : </span><input type="text" name="code" /><br>
<span>Product Name : </span><input type="text" name="name" /><br>
<span>Cost : </span><input type="text" name="cost" /><br>
<span>Price : </span><input type="text" name="price" /><br>
<span>Supplier : </span>
<select name="supplier">
	<?php
 include '../configuration.php';
$sql= "SELECT *  FROM 	supliers";
$result= mysql_query($sql) or die(mysql_error());
while($row=mysql_fetch_array($result))
			     {
	?>
		<option><?php echo $row['suplier_name']; ?></option>
	<?php
	}
	?>
</select>

<br>
<span>Qty : </span><input type="text" name="qty" /><br>
<span>Expiry : </span><input type="text" name="expiryDate" value="<?php echo date('Y-m-d');?>" /><br>
<span>&nbsp;</span><input id="btn" type="submit" value="save" />
</div>
</form>