<?php
	require_once('../auth.php');
	require('../configuration.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Vine eye center management system</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<!--sa poip up-->
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>



<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
.style19 {font-size: 24px; font-family: Geneva, Arial, Helvetica, sans-serif; }
-->
</style>

<script type="text/javascript">
function confirmationDelete(anchor)
{
   var conf = confirm('Are you sure want to delete this record?');
   if(conf)
      window.location=anchor.attr("href");
}
</script>

  
  
</head>
<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
			
			
			
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">
<?php
error_reporting(E_ALL^E_NOTICE);
////////////////////////////////////////////////////////
$per_page =20;
            $pages_query =  mysql_query("SELECT COUNT(product_id) FROM products");
			$pages = ceil(mysql_result($pages_query, 0) / $per_page);
			$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
			$start = ($page - 1) * $per_page;
			

/////////////////////////////////////////////////////////
?>
      <table width="669" align="center">
        <tr>
          <td height="20" colspan="2"><h2 align="center"><span class="style1">  view Products panel</span></h2></td>
        </tr>
        <tr>
          <td width="417">
		 <a href="index.php?action=index"><button>Home</button></a> &nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;

	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
          <td width="240">
		  	<form name="searchForm" action="search_index_product.php" method="POST">
		  		<input type="textfield" name="search" placeholder="Search product" />
				<button type="submit">Search</button>
		  	</form>
		  </td>
        </tr>
    </table>
<script type="text/javascript">
             $(document).ready(function()
                {
                    $("#myTable").tablesorter({widgets: ['zebra']})
                                 .tablesorterPager({ container: $("#pagerOne"), positionFixed: false })
                }
            );
         </script>
  </div>
  <!--###########################################################################-->
 <div class="add-user-main-panel">
	<table width="669" align="center">
	 	<?php


			$qry = mysql_query("select * from products  WHERE qty > 0 LIMIT $start, $per_page ");
			if(!$qry){echo mysql_error();}else{
				echo '	<style>
							th{text-align:center;background:#000099;color:#fff;padding:5px;font-size:14px;}
							tr{text-align:center;}
							a{text-decoration:none;}
						</style>

						<th>P/No</th><th>Code</th><th>Name</th><th>Cost</th><th>Price</th><th>Qty</th><th>Actions</th>';
				$sno = 0;
				while($row = mysql_fetch_array($qry)){
					$id = $row['product_id'];
					$product_code = $row['product_code'];
					$product_name = $row['product_name'];
					$cost = $row['cost'];
					$price = $row['price'];
					$supplier = $row['supplier'];
					$qty = $row['qty'];
					$dateIn = $row['dateIn'];
					$expiryDate = $row['expiryDate'];
					
					

					$sno = $sno + 1;

				echo '<tr>
						<td>'.$sno.'</td>
						<td>'.$product_code.'</td>
						<td>'.$product_name.'</td>
						<td>'.$cost.'</td>
						<td>'.$price.'</td>
						<td>'.$qty.'.00</td>
						<td>
						    <a rel="facebox"  href="addproduct.php?viewid='.$id.'"><img src="images/add.png" height="10" width="20" title="add product"></a>
							
							<a href="view_single_product.php?product_id='.$id.'"><img src="images/view.png" title="View More Infor"></a>
							
							<a rel="facebox" href="editproduct.php?product_id='.$id.'"><img src="images/edit.png" title="Update"></a>

							<a onclick="confirmationDelete(this);return false;" href="deleteproduct.php?product_id='.$id.'"><img src="images/close.png" title="Delete"></a>
						</td>
					</tr>';
				}
			}



		?>
<tr id="pagerOne">
    <td colspan="6"> <?php 
		if($pages>=1 && $page<=$pages)
{
echo " Page   "; 
for($x=1; $x<=$pages;$x++)
{
//echo '<a href="?page='.$x.'">'.$x.'</a>';

echo($x==$page) ? '<strong><a href="?page='.$x.'" style="text-decoration:none">'.$x.'          </a>&nbsp;</strong>                   ' : '<a href="?page='.$x.'">'.$x.'               </a> &nbsp;              ';
}
}
	echo "   of $pages pages";
		?>
    </td>
	</tr>
     </table>
 </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
