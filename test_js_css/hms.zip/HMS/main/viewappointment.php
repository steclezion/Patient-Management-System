<?php 
include '../auth.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Vine eye center management system</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="../style.css" rel="stylesheet" type="text/css" />    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">	
	<link rel="stylesheet" href="style.css"/>
	<script src="js/jquery-1.4.2.min.js" type="text/javascript"></script>
	<link href="../style.css" rel="stylesheet" type="text/css" />


<style type="text/css">
.blink_text {

animation:1s blinker linear infinite;
-webkit-animation:1s blinker linear infinite;
-moz-animation:1s blinker linear infinite;

 color: blue;
}

@-moz-keyframes blinker {  
 0% { opacity: 1.0; }
 50% { opacity: 0.0; }
 100% { opacity: 1.0; }
 }

@-webkit-keyframes blinker {  
 0% { opacity: 1.0; }
 50% { opacity: 0.0; }
 100% { opacity: 1.0; }
 }

@keyframes blinker {  
 0% { opacity: 1.0; }
 50% { opacity: 0.0; }
 100% { opacity: 1.0; }
 }
 </style>
 
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
-->
</style>
</head>
		<SCRIPT TYPE="text/javascript"> 
 
var message="Sorry, right-click has been disabled"; 

function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 

</SCRIPT>
<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
			<script type="text/javascript">

function getAge(){
    var dob = document.getElementById('date').value;
    dob = new Date(dob);
    var today = new Date();
    var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
    document.getElementById('age').value=age;
}

</script>
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">
  
  
   <table width="669" align="center">
        <tr>
          <td height="43" colspan="2"><h2 align="center"><span class="style1"> Welcome to patient's Form </span></h2></td>
        </tr>
        <tr>
          <td width="417">
		  	<a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  <a href="add_patient.php?action=add"><button>New Patient</button></a>&nbsp;
		  <a href="viewpat.php?action=view"><button>View</button></a>&nbsp;

	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
        
        </tr>
    </table>
  </div>
  
  <!--###########################################################################-->
 <div class="add-user-main-panel">
 <table id="resultTable" class="hovertable" align="center"  data-responsive="table">
	<h3 align="center">Appointments this week</h3>
	<?php 
   $conn = mysql_connect('localhost', 'root', '');
   mysql_select_db('HIMS', $conn);
   $days = range(1,31);
   $months = range(1,12);
   $years = range(2016,2020);
   $getrecoverynoti = mysql_query("select * from members,patients   WHERE members.FullName=patients.No AND members.ReminderDate >= DATE(now()) and members.ReminderDate <= DATE_ADD(DATE(now()), INTERVAL 5 DAY) and ReminderDate >= NOW() ORDER BY ABS( DATEDIFF( ReminderDate, NOW())) Limit 10")or die(mysql_error());
   $countrecovery = mysql_num_rows($getrecoverynoti);
?>
	<thead>


<tr>  
  <th >Event Name</th>
  <th>Note</th>
  <th >Reminder Date</th>
  <th>Contact</th>
  <th>Left Days</th>
</tr>
</thead>
<?php
 while($recoverynoti = mysql_fetch_array($getrecoverynoti))
 { 
  $reminder = date('d-M-Y',strtotime(date("d-m-Y", strtotime($recoverynoti['ReminderDate'])) . " +0 days"));
?>
<tbody >
		
     <tr onmouseover="this.style.backgroundColor='#C9BA37';"  onmouseout="this.style.backgroundColor='#FCF3B0';">
     <td ><span class="blink_text"><?php echo $recoverynoti['fname'];  ?>-<?php echo $recoverynoti['lname'];?> </span></td>
      <td ><span class="blink_text"><?php echo $recoverynoti['Note']; ?></span></td>
      <td ><span class="blink_text"><?php echo $reminder; ?></td> 
      <td ><span class="blink_text">0<?php echo $recoverynoti['tel']; ?></td> 
      <td  ><span class="blink_text"><?php echo (strtotime($reminder) - strtotime(date('d-M-Y'))) / (60 * 60 * 24).'Day(s)'; ?></span></td> 
     </tr>					
<?php } ?>	
	</tbody>
 									  
</table> 
<br>
</div><div class="clearfix"></div><div class="clearfix">
 </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
