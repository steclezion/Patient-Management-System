<?php
	require_once('../auth.php');
	require('../configuration.php');
	
	$id = $_REQUEST['verifyid'];
	
	$qry = mysql_query("Update patients set verify = 'verified.png' where No = '$id'");
	
	echo '<script> location="view_indivdiagnosed_patient.php?viewid='.$id.'"; </script>';

?>