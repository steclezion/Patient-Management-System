<?php
	require_once('../auth.php');
		include('../configuration.php');

?>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<table id="resultTable" data-responsive="table" style="text-align: left;">
	<thead>
		<tr>
			<th width="5%"> Medicine Name </th>
		</tr>
	</thead>
	<tbody>
		
			
			<?php
                       $id=$_GET['No'];
				$sql=mysql_Query ("SELECT *  From treatment WHERE received='Not-yet' AND pNo='$id'");
				while ($row = mysql_fetch_assoc($sql)) {
			?>
			<tr class="record">
			<td><?php echo $row['medicineName']; ?></td>
			
			
			</tr>
	<?php
				}
			?>
			</td>
			
			</tr>

		
	</tbody>
</table>