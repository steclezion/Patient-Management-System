<?php
	require_once('../auth.php');
require('../configuration.php');


$No = $_POST['aaa'];
$pinhole = $_POST['pinhole'];
$V_A = $_POST['V_A'];
$glasses = $_POST['glasses'];
$PD = $_POST['PD'];
$vission = $_POST['vission'];
$a = $_POST['a'];
$b = $_POST['b'];
$c = $_POST['c'];
$d = $_POST['d'];
$e = $_POST['a2'];
$f = $_POST['b2'];
$g = $_POST['c2'];
$h = $_POST['d2'];
$PD2 = $_POST['PD2'];
$V_A2 = $_POST['V_A2'];
$glasses2 = $_POST['glasses2'];
$vission2 = $_POST['vission2'];
$a1 = $_POST['a3'];
$b2 = $_POST['b3'];
$c2 = $_POST['c3'];
$d2 = $_POST['d3'];
$e2 = $_POST['a4'];
$f2 = $_POST['b4'];
$g2 = $_POST['c4'];
$h2 = $_POST['d4'];
$pinhole2 = $_POST['pinhole2'];


$qry = mysql_query("
	insert into diagnosis
	
	values(
	
		'',
		'$No',
		'Null',
		'Null',
		'Null',
		'Null',
		'Null',
		'Null',
		'Null',
		'Null',
		'$pinhole',
		'$PD',
		'Null',
		'Null',
		'Null',
		'Null',
		'$V_A',
		'$glasses',
		'$a',
		'$b',
		'$c',
		'$d',
		'$e',
		'$f',
		'$g',
		'$h',
		'$vission',
		'Null',
		'Null',
		'Null',
		
		'Null',
		'Null',
		'Null',
		'Null',
		'Null',
		'Null',
		'Null',
		'Null',
		'$pinhole2',
		'$PD2',
		'Null',
		'Null',
		'Null',
		'Null',
		'$V_A2',
		'$glasses2',
		'$a1',
		'$b2',
		'$c2',
		'$d2',
		'$e2',
		'$f2',
		'$g2',
		'$h2',
		'Null',
		'$vission2',
		'Null',
		'Null'
	)
	");

			if($qry){

				echo ' Your data has been inserted, Please wait... ';

				echo '<script type="text/javascript">

						var myVar=setInterval(function(){myTimer()},2000);

				function myTimer()
				{
					window.location="viewDiagno_techn.php";

				}
			</script>';
			}else {	echo mysql_error();	}

	
	

?>