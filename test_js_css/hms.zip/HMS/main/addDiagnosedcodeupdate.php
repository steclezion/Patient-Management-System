<?php
	require_once('../auth.php');
require('../configuration.php');


$No = $_POST['patNo'];
$vission = $_POST['vission'];
$pinhole = $_POST['pinhole'];
$V_A = $_POST['V_A'];
$glasses = $_POST['glasses'];
$PD = $_POST['PD'];
$a = $_POST['a'];
$b = $_POST['b'];
$c = $_POST['c'];
$d = $_POST['d'];
$e = $_POST['a2'];
$f = $_POST['b2'];
$g = $_POST['c2'];
$h = $_POST['d2'];

$vission2 = $_POST['vission2'];
$pinhole2 = $_POST['pinhole2'];
$PD2 = $_POST['PD2'];
$V_A2 = $_POST['V_A2'];
$glasses2 = $_POST['glasses2'];

$a1 = $_POST['a3'];
$b2 = $_POST['b3'];
$c2 = $_POST['c3'];
$d2 = $_POST['d3'];
$e2 = $_POST['a4'];
$f2 = $_POST['b4'];
$g2 = $_POST['c4'];
$h2 = $_POST['d4'];


$qry = mysql_query("UPDATE diagnosis SET
 vission='$vission',
pinhole='$pinhole', 
V_A='$V_A',
glasses='$glasses', 
PD='$PD', 
a='$a',
 b='$b', 
 c='$c',
 d='$d',
 a2='$e',
 b2='$f',
 c2='$g', 
 d2='$h',
 vission2='$vission2',
pinhole2='$pinhole2', 
glasses2='$glasses2',
V_A2='$V_A2',
a3='$a1', 
b3='$b2', 
c3='$c2',
d3='$d2', 
a4='$e2', 
b4='$f2',
c4='$g2', 
d4='$h2' 
WHERE patNo='$No' ");
	
			if($qry){

				echo ' Your data fill part has been updated, Please wait... ';

				echo '<script type="text/javascript">

						var myVar=setInterval(function(){myTimer()},2000);

				function myTimer()
				{
					window.location="viewDiagno_techn.php";

				}
			</script>';
			}else {	echo mysql_error();	}

	
	

?>