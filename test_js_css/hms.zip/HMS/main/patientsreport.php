<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="Dayspatpdf.php" method="post">
<div id="ac">
<span>Select Day:</span>
<input type="text" name="from" id="textbox" value="<?php echo date('m/d/Y')?>" required="required"/><br>
<span>Select Day:<span><input type="text" name="to" id="textbox" value="<?php echo date('m/d/Y')?>" required="required"/>
<span>&nbsp;</span><input id="btn" type="submit" name="submit" value="save" />
</div>
</form>