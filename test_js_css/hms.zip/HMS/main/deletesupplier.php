<?php
include('../configuration.php');
	$id=$_GET['suplier_id'];
	$result = $db->prepare("DELETE FROM supliers WHERE suplier_id= :memid");
	$result->bindParam(':memid', $id);
	$result->execute();
	header("location: viewsupplier.php");

?>