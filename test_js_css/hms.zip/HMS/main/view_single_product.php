<?php
	require_once('../auth.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>###############################t</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />

<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
.style20 {font-size: 14px}
-->
</style>
</head>

<body>
<div class="add-container">
  <div class="banner-div">
     <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

      <table width="669" align="center">
        <tr>
          <td height="43" colspan="2"><h2 align="center"><span class="style2"> Welcome to individual patient view </span></h2></td>
        </tr>
        <tr>
        <td width="417">
		  	<a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  <a href="viewpat.php?action=view"><button>View</button></a>&nbsp;

	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td> 
	</tr>
    </table>

  </div>
  <!--###########################################################################-->
 <div class="add-user-main-panel">
	 <table width="669" align="center">
	 	<?php

			require('../configuration.php');

			$id = $_REQUEST['product_id'];

			$qry = mysql_query("select * from products where product_id = '$id'");
			if(!$qry){echo mysql_error();}else{

				while($row = mysql_fetch_array($qry)){
					$id = $row['product_id'];
					$product_code = $row['product_code'];
					$product_name = $row['product_name'];
					$cost = $row['cost'];
					$price = $row['price'];
					$supplier = $row['supplier'];
					$qty = $row['qty'];
					$dateIn = $row['dateIn'];
					$expiryDate = $row['expiryDate'];
				}
			}


		?>
       

		<tr>
		<td><span class="style20">Product Code: <font color="green"><?php echo $product_code; ?> </font></span></td>
	   </tr>
		<tr>
		  <td><span class="style20">product Name: <font color="green"><?php echo $product_name; ?></font></span></td>
	   </tr>
		<tr>
		  <td><span class="style20">Cost: <font color="green"><?php echo $cost; ?></font></span></td>
	   </tr>
	   <tr>
		  <td><span class="style20">Price: <font color="green"><?php echo $price; ?></font></span></td>
	   </tr>
	   <tr>
		  <td><span class="style20">Supplier: <font color="green"><?php echo $supplier; ?></font></span></td>
	   </tr>
	    <tr>
	      <td><span class="style20">Quantity: <font color="green"><?php echo $qty; ?></font></span></td>
       </tr>
	   <tr>
	      <td><span class="style20">Date Entry: <font color="green"><?php echo $dateIn; ?></font></span></td>
       </tr>
	   <tr>
	      <td><span class="style20">Expiry Date: <font color="green"><?php echo $expiryDate; ?></font></span></td>
       </tr>
	   
       <tr>
	      <td>&nbsp;</td>
       </tr>
     </table>
 	</div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
