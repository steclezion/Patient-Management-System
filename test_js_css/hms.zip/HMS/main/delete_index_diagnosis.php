<?php
session_start();
require("../configuration.php");

$id = $_REQUEST['No'];

$qry = mysql_query("delete from patients where No='$id'");

if($qry){ echo '<script>alert("Deleted successfully");location="viewpat.php?action=deleted";</script>';}else{echo mysql_error();}





?>