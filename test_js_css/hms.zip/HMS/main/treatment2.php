
<?php
	require_once('../auth.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>vine eye center</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="../style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery-1.8.0.min.js"></script>
<script type="text/javascript" src="js/script.js"></script> 
<script type="text/javascript">
$(function(){
$(".search").keyup(function() 
{ 
var searchid = $(this).val();
var dataString = 'search='+ searchid;
if(searchid!='')
{
	$.ajax({
	type: "POST",
	url: "search.php",
	data: dataString,
	cache: false,
	success: function(html)
	{
	$("#result").html(html).show();
	}
	});
}return false;    
});

jQuery("#result").live("click",function(e){ 
	var $clicked = $(e.target);
	var $name = $clicked.find('.name').html();
	var decoded = $("<div/>").html($name).text();
	$('#searchid').val(decoded);
});
jQuery(document).live("click", function(e) { 
	var $clicked = $(e.target);
	if (! $clicked.hasClass("search")){
	jQuery("#result").fadeOut(); 
	}
});
$('#searchid').click(function(){
	jQuery("#result").fadeIn();
});
});
</script>
<style type="text/css">
	body{ 
		font-family:Tahoma, Geneva, sans-serif;
		font-size:18px;
	}
	.content{
		width:900px;
		margin:0 auto;
	}
	#searchid
	{
		width:500px;
		border:solid 1px #000;
		padding:10px;
		font-size:14px;
	}
	#result
	{
		position:absolute;
		width:500px;
		padding:10px;
		display:none;
		margin-top:-1px;
		border-top:0px;
		overflow:hidden;
		border:1px #CCC solid;
		background-color: white;
	}
	.show
	{
		padding:10px; 
		border-bottom:1px #999 dashed;
		font-size:15px; 
		height:50px;
	}
	.show:hover
	{
		background:#4c66a4;
		color:#FFF;
		cursor:pointer;
	}
</style>
</head>
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
-->
</style>
<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
		
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

       <table width="669" align="center">
        <tr>
          <td height="43" colspan="2"><h2 align="center"><span class="style1">Doctor's diagnosis Form </span></h2></td>
        </tr>
        <tr>
           <td width="417">
		  <a href="index.php?action=index"><button>Home</button></a> &nbsp;
		  		  <a href="viewDiagno.php?action=add"><button>View Diagnosed</button></a>&nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;
	
	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
         
    </table>

  </div>
    <!--###########################################################################-->
 <div class="add-user-main-panel">
 <form action="treatmentcode.php" method="POST" class="register">
<?php
			
			require('../configuration.php');

			$id = $_REQUEST['viewid'];

			$qry = mysql_query("select * from diagnosis d,patients p where d.patNo=p.No AND d.patNo = '$id'");
			if(!$qry){echo mysql_error();}else{

				while($row = mysql_fetch_array($qry)){
					$id = $row['No'];
					$passport = $row['pport'];
					
				}
			}

			
			

		?>
	 <table width="669" align="center">
	 	<tr>
			<td width="122" rowspan="5"><img src="profile/<?php echo $passport; ?>" alt="Passport" width="147" height="137" /><br />
				<input id="textfield"type="hidden" name="pNo" value="<?php echo $id; ?>" />
				
		    <td width="535">Make sure you use valid information for this registration, because it is very important to this institute for future use. </td>
	 	</tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
	 	<tr>
	 	  <td>&nbsp;</td>
 	    </tr>
     </table>
<hr />
	 <table width="669" align="center">
    <tr> 
	<td><input type="button" value="Add Treatment" onClick="addRow('dataTable')" /> </td>
					<td><input type="button" value="Remove Treatment" onClick="deleteRow('dataTable')"  /> </td>
					<p>(All actions apply only to entries with check marked check boxes only.)</p>
				
               <table id="dataTable" width="669">
                  <tbody>
                    <tr>
                      <p>
					  <td><input type="checkbox"  required="required" name="chk[]" checked="checked" /></td>
						<div id="result">
                        </div>
                       <td>
							<label>Medicine Name</label>
<!--<div class="content">-->
<input type="text" class="search" id="searchid"  name="medicineName[]" placeholder="Search for people" /><br /> 
<div id="result">
</div>
<!--</div>-->
</td>
						 
						 </td>
							</p>
                    </tr>
                    </tbody>
                </table>
				<div class="clear"></div>
	  </table>

<hr />

<hr />

 <table width="669" align="center">
		<tr>
		  <td bgcolor="#000000"><span class="style3">Before submitting, make sure that all the information you used is correct</span></td>
	    </tr>
	 </table>
	 
<hr/>
	  <table width="669" align="center">
		<tr>
		  <td colspan="2"><label for="Submit"></label>
	      <input type="submit" name="submit" value="Submit" id="Submit" /></td></form>
        </tr>
	 </table>


    
  </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
