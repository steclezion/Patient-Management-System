<?php
	require_once('../auth.php');
require('../configuration.php');

$id = $_REQUEST['id'];
$target_path = "profile/";
$target_path = $target_path . basename( $_FILES['uploadedfile']['name']);
if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)){

	$image = basename( $_FILES['uploadedfile']['name']);
	



$title = $_POST['title'];
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$gender = $_POST['gender'];
$dob = $_POST['dob'];
$age = $_POST['age'];
$tel = $_POST['tel'];
$address = $_POST['address'];
$dEntry = $_POST['dEntry'];


$sql = mysql_query("UPDATE `patients` SET `pport` = '$image', 
		
		`title` = '$title',
		`fname` = '$fname',
		`mname` = '$mname',
		`lname` = '$lname',
		`gender` = '$gender',
		`dob` = '$dob',
		`age` = '$age',
		`tel` = '$tel',
		`address` = '$address',
		`dEntry` = '$dEntry'
		
			
		where No = '$id'");

		if($sql){ echo '<script>alert("Updated");location="viewpat.php?action=updated";</script>'; }else{echo mysql_error();}

	}
	else{
		echo mysql_error();
		}

?>