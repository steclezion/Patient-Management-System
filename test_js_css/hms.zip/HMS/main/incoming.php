
<?php
require_once('../auth.php');
include('../configuration.php');
$a = $_POST['invoice'];
$b = $_POST['product'];
$c = $_POST['qty'];
$w = $_POST['pt'];
$date = date('m/d/Y');
$discount = $_POST['discount'];
$result = $db->prepare("SELECT * FROM products WHERE product_code= :userid");
$result->bindParam(':userid', $b);
$result->execute();
for($i=0; $row = $result->fetch(); $i++){
$asasa=$row['price'];
$cost=$row['cost'];
$quantity=$row['qty'];
$name=$row['product_name'];
}

//edit qty
$sql = "UPDATE products 
        SET qty=qty-?
		WHERE product_code=?";
$q = $db->prepare($sql);
$q->execute(array($c,$b));
$fffffff=$asasa-$discount;
$d=$fffffff*$c;
$e=$cost/$quantity;
$h=$e*$c;
$f=$d*$c-$h;
// query
$sql = "INSERT INTO sales_order (invoice,product,qty,amount,name,price,discount,profit,datesold,cashed) VALUES (:a,:b,:c,:d,:e,:f,:g, :h, :i,:j)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':e'=>$name,':f'=>$asasa,':g'=>$discount,':h'=>$f,':i'=>$date,':j'=>'uncashed'));
header("location: sales.php?id=$w&invoice=$a");


?>