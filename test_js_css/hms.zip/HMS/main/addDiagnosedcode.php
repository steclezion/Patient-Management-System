





<?php
	require_once('../auth.php');
require('../configuration.php');
?>
<?php
$No = $_POST['patNo'];
$checkbox1 = $_POST['procname'];
$patno = $_POST['patNo'];
for ($i=0; $i<sizeof($checkbox1);$i++) {
	$query="INSERT INTO  procedurers (procname,paNo,status) VALUES ('".$checkbox1[$i]."','".$patno."','unconfirmed')";
	mysql_query($query) or die (mysql_error());
}


?>

<?php


$No = $_POST['patNo'];
$iop = $_POST['iop'];
$complaint = $_POST['complaint'];
$cornea = $_POST['cornea'];
$pupil = $_POST['pupil'];
$desease = $_POST['desease'];
$eyelid = $_POST['eyelid'];
$conj_ctive = $_POST['conj_ctive'];
$A_C = $_POST['A_C'];
$Vitroeus = $_POST['Vitroeus'];
$retina = $_POST['retina'];
$Vitroeus = $_POST['Vitroeus'];
$opticalnerve = $_POST['opticalnerve'];
$C_D_R = $_POST['C_D_R'];
$Pressure = $_POST['Pressure'];
$others = $_POST['others'];
$desease = $_POST['desease'];
$lence = $_POST['lence'];


$iop2 = $_POST['iop2'];
$cornea2 = $_POST['cornea2'];
$pupil2 = $_POST['pupil2'];
$complaint2 = $_POST['complaint2'];
$eyelid2 = $_POST['eyelid2'];
$conj_ctive2 = $_POST['conj_ctive2'];
$desease2 = $_POST['desease2'];
$A_C2 = $_POST['A_C2'];
$lence2 = $_POST['lence2'];
$Vitroeus2 = $_POST['Vitroeus2'];
$retina2 = $_POST['retina2'];
$Pressure2 = $_POST['Pressure2'];
$C_D_R2 = $_POST['C_D_R2'];
$opticalnerve2 = $_POST['opticalnerve2'];
$others2 = $_POST['others2'];



$qry = mysql_query("
	UPDATE diagnosis SET
	iop='$iop',
	cornea='$cornea',
	pupil='$pupil',
	complaint='$complaint',
	eyelid='$eyelid',
	conj_ctive='$conj_ctive',
	C_D_R='$C_D_R',
	A_C='$A_C',
	desease='$desease',
	lence='$lence',
	Vitroeus='$Vitroeus',
	retina='$retina',
	opticalnerve='$opticalnerve',
	Pressure='$Pressure',
	others='$others',
	desease='$desease',

	iop2='$iop2',
	cornea2='$cornea2',
	pupil2='$pupil2',
	complaint2='$complaint2',
	eyelid2='$eyelid2',
	conj_ctive2='$conj_ctive2', 
	A_C2='$A_C2', 
	lence2='$lence2', 
	Vitroeus2='$Vitroeus2', 
	retina2='$retina2', 
	opticalnerve2='$opticalnerve2', 
	C_D_R2='$C_D_R2', 
	Pressure2='$Pressure2', 
	others2='$others2', 
	desease2='$desease2' 
	WHERE patNo='$No'");
	
	

			if($qry){

				echo ' Your patient form has been updated, Please wait... ';

				echo '<script type="text/javascript">

						var myVar=setInterval(function(){myTimer()},2000);

				function myTimer()
				{
					window.location="viewDiagno.php";

				}
			</script>';
			}else {	echo mysql_error();	}

	
	

?>