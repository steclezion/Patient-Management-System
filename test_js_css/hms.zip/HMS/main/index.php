<?php
	require_once('../auth.php');
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Vine eye center management system</title>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>

<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style3 {color: #FFFFFF}
.style19 {font-size: 24px; font-family: Geneva, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body>
<div class="add-container">
  <div class="banner-div">
   <div class="logo"> <img src="images/baner.png"	 /> </div>
    <!--<div class="site-title style3">Eye Clinic Management System</div>
    <div class="site-slogan">Kazaure L.G.A. Secretriate </div>-->
    <div class="date">
      <script language="JavaScript" type="text/javascript">
      			document.write(TODAY);
			</script>
    </div>
    <div class="time">
      <script type="text/javascript">
				<!--
				var currentTime = new Date()
				var hours = currentTime.getHours()
				var minutes = currentTime.getMinutes()
				if (minutes < 10){
				minutes = "0" + minutes
				}
				document.write(hours + ":" + minutes + " ")
				if(hours > 11){
				document.write("PM")
				} else {
				document.write("AM")
				}
				//-->
			</script>
					<SCRIPT TYPE="text/javascript"> 
 
var message="Sorry, right-click has been disabled"; 

function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 

</SCRIPT>
    </div>
  </div>
  <!--end of banner-->
  <div class="add-user-menus-panel">

      <table width="669" align="center">
        <tr>
          <td height="20" colspan="2"><h2 align="center"><span class="style1"> Welcome to the system </span></h2></td>
        </tr>
        <tr>
		<?php
$position=$_SESSION['SESS_LAST_NAME'];
if($position=='secretary') {
?>
          <td width="417"><a href="add_patient.php?action=add"><button>New Patient</button></a>&nbsp;
		  <a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;
	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
          <td width="240">
		  	<form name="searchForm" action="search_index_patient.php" method="POST">
		  		<input type="textfield" name="search" placeholder="Search patient" />
				<button type="submit">Search</button>
		  	</form>
		  </td>
        </tr>
    </table>
<?php
}
?>
<?php
if($position=='technician') {
?>
          <td width="417">
		  <a href="viewDiagno_techn.php?action=view"><button>View Diagnosed</button></a>&nbsp;
		  <a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;
	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
          
        </tr>
    </table>
<?php
}
?>


<?php
if($position=='admin') {
?>
      <td width="417"><a href="viewDiagno.php?action=view"><button>View Diagnosed</button></a>&nbsp;
	<a href="logout.php?action=logged%out"><button>LogOut</button></a> &nbsp;
	<font color="red" size="1">Current User: </font><font color="green" size="1"><?php echo $_SESSION['SESS_FIRST_NAME']; ?></font>

	</td>
          <td width="240">
		  	<form name="searchForm" action="search_index_Diagnosis.php" method="POST">
		  		<input type="textfield" name="search" placeholder="Search diagnosed" />
				<button type="submit">Search</button>
		  	</form>
		  </td>
        </tr>
    </table>
<?php
}
?>

  </div>
  <!--###########################################################################-->
 <div class="add-user-main-panel">
	 <table width="669"  align="center">
	 <?php
function createRandomPassword() {
	$chars = "003232303232023232023456789";
	srand((double)microtime()*1000000);
	$i = 0;
	$pass = '' ;
	while ($i <= 7) {

		$num = rand() % 33;

		$tmp = substr($chars, $num, 1);

		$pass = $pass . $tmp;

		$i++;

	}
	return $pass;
}
$finalcode='RS-'.createRandomPassword();
?>
	 	<div id="mainmain">
<?php
$position=$_SESSION['SESS_LAST_NAME'];
if($position=='secretary') {
?>
<a href="recommendations.php">RecomddTreatment</a>
<a href="viewpat.php">ViewPatients</a>
<a rel="facebox" href="patientsreport.php">Report Patients</a>
<a href="stocklevel.php">Stoke level</a>
<!--<a href="expired.php">Outdated Stoke</a>-->
<a href="viewproducts.php">Products</a>
<a href="viewsupplier.php">Suppliers</a>
<a href="purchaseslist.php">Purchases</a>
<a rel="facebox" href="select_patient.php">Patient Ledger</a>
<a href="sales.php?id=cash&invoice=<?php echo $finalcode ?>">Cash</a>
<a href="sales.php?id=credit&invoice=<?php echo $finalcode ?>">Credit</a>
<a href="logout.php?action=logged%out">Logout</a>
<?php
}
if($position=='technician') {
?>
<a rel="facebox" href="search_patient.php">New Patient</a>
<a rel="facebox" href="search_patient_old.php">Old Patient</a>
<a href="logout.php?action=logged%out">Logout</a>
<?php
}
if($position=='admin') {
?>
<a href="recommendations2.php">RecomddTreatment</a>
<a  href="appointment.php">Make Appointment</a>
<a  href="viewappointment.php">View Appointments</a>
<a href="sales.php?id=cash&invoice=<?php echo $finalcode ?>">Cash</a>
<a href="sales.php?id=credit&invoice=<?php echo $finalcode ?>">Credit</a>
<a href="salesreport.php?d1=0&d2=0">Sales Report</a>
<a  href="reportprofit.php?d1=0&d2=0">ReportProfit</a>
<a href="collection.php?d1=0&d2=0">Collection Report</a>
<a href="accountreceivables.php?d1=0&d2=0">Accounts Receivable Report</a>
<a rel="facebox" href="select_patient.php">Patient Ledger</a>
<a href="viewpatient.php">View patients</a>
<a rel="facebox" href="searchdiagnosedPatient.php">Diagnose Old</a>
<a rel="facebox" href="Diagnosis_new_search.php">Diagnosis New</a>



<a href="purchaseslist.php">Purchases</a>
<a href="logout.php?action=logged%out">Logout</a>
<?php
}
?>
<div class="clearfix"></div>
</div>
     </table>
  </div><div class="footer-div">
<h5 align="center"><font color="white">Created by <a href="nevillemwije@gmail.com">Developer</a> @ <a href="https://0.facebook.com/nevidots/">Facebook</a> | Contact me at</font><font color="black"> 0787809808/0752855715</font></h5>

 	</div><div class="footer-div"></div>
</div>
</body>
</html>
