-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 29, 2016 at 10:19 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hims`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `user`, `pass`, `role`) VALUES
(1, 'neville', 'ac0203e52da9f7d4d70fd02b661c41d1', 'admin'),
(2, 'teta', 'd9c4b80884a6623851c5b6cd6a0a001a', 'secretary'),
(3, 'tech', 'd9f9133fb120cd6096870bc2b496805b', 'technician');

-- --------------------------------------------------------

--
-- Table structure for table `collection`
--

CREATE TABLE IF NOT EXISTS `collection` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `balance` int(11) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `collection`
--

INSERT INTO `collection` (`transaction_id`, `date`, `name`, `invoice`, `amount`, `remarks`, `balance`) VALUES
(1, '09/23/2016', 'RS-302363', 'IN-228', '15', 'balance', 5),
(2, '09/24/2016', 'RS-302363', 'IN-9203703', '5', 'cleared', 0);

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis`
--

CREATE TABLE IF NOT EXISTS `diagnosis` (
  `did` int(200) NOT NULL AUTO_INCREMENT,
  `patNo` varchar(20) NOT NULL,
  `cornea` varchar(100) NOT NULL,
  `A_C` varchar(100) NOT NULL,
  `pupil` varchar(100) NOT NULL,
  `lence` varchar(100) NOT NULL,
  `Vitroeus` varchar(100) NOT NULL,
  `retina` varchar(100) NOT NULL,
  `opticalnerve` varchar(100) NOT NULL,
  `C_D_R` varchar(100) NOT NULL,
  `pinhole` varchar(100) NOT NULL,
  `PD` varchar(100) NOT NULL,
  `complaint` varchar(100) NOT NULL,
  `Pressure` varchar(100) NOT NULL,
  `eyelid` varchar(100) NOT NULL,
  `conj_ctive` varchar(100) NOT NULL,
  `V_A` varchar(100) NOT NULL,
  `glasses` varchar(100) NOT NULL,
  `a` varchar(100) NOT NULL,
  `b` varchar(100) NOT NULL,
  `c` varchar(100) NOT NULL,
  `d` varchar(100) NOT NULL,
  `a2` varchar(100) NOT NULL,
  `b2` varchar(100) NOT NULL,
  `c2` varchar(100) NOT NULL,
  `d2` varchar(100) NOT NULL,
  `vission` varchar(100) NOT NULL,
  `iop` varchar(100) NOT NULL,
  `others` text NOT NULL,
  `desease` varchar(100) NOT NULL,
  `cornea2` varchar(100) NOT NULL,
  `A_C2` varchar(100) NOT NULL,
  `pupil2` varchar(100) NOT NULL,
  `lence2` varchar(100) NOT NULL,
  `Vitroeus2` varchar(100) NOT NULL,
  `retina2` varchar(100) NOT NULL,
  `opticalnerve2` varchar(100) NOT NULL,
  `C_D_R2` varchar(100) NOT NULL,
  `pinhole2` varchar(100) NOT NULL,
  `PD2` varchar(100) NOT NULL,
  `complaint2` varchar(100) NOT NULL,
  `Pressure2` varchar(100) NOT NULL,
  `eyelid2` varchar(100) NOT NULL,
  `conj_ctive2` varchar(100) NOT NULL,
  `V_A2` varchar(100) NOT NULL,
  `glasses2` varchar(100) NOT NULL,
  `a3` varchar(100) NOT NULL,
  `b3` varchar(100) NOT NULL,
  `c3` varchar(100) NOT NULL,
  `d3` varchar(100) NOT NULL,
  `a4` varchar(100) NOT NULL,
  `b4` varchar(100) NOT NULL,
  `c4` varchar(100) NOT NULL,
  `d4` varchar(100) NOT NULL,
  `desease2` varchar(100) NOT NULL,
  `vission2` varchar(100) NOT NULL,
  `iop2` varchar(100) NOT NULL,
  `others2` text NOT NULL,
  PRIMARY KEY (`did`),
  KEY `patNo` (`patNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `diagnosis`
--

INSERT INTO `diagnosis` (`did`, `patNo`, `cornea`, `A_C`, `pupil`, `lence`, `Vitroeus`, `retina`, `opticalnerve`, `C_D_R`, `pinhole`, `PD`, `complaint`, `Pressure`, `eyelid`, `conj_ctive`, `V_A`, `glasses`, `a`, `b`, `c`, `d`, `a2`, `b2`, `c2`, `d2`, `vission`, `iop`, `others`, `desease`, `cornea2`, `A_C2`, `pupil2`, `lence2`, `Vitroeus2`, `retina2`, `opticalnerve2`, `C_D_R2`, `pinhole2`, `PD2`, `complaint2`, `Pressure2`, `eyelid2`, `conj_ctive2`, `V_A2`, `glasses2`, `a3`, `b3`, `c3`, `d3`, `a4`, `b4`, `c4`, `d4`, `desease2`, `vission2`, `iop2`, `others2`) VALUES
(1, '2016-09-24-1', 'dry', 'Flare', 'Synichea', 'P.C.O', 'cells', 'csme', 'cupped', 'e', '6/4', '4', 'red eye', 'e', 'tear', 'injection', '2.3', '3', '4', '42', '42', '4', '42', '4', '4', '42', '', 'e', 'e', 'e', 'dry', 'Flare', 'Synichea', 'P.C.O', 'cells', 'csme', 'cupped', 'f', '6/4', '42', 'red eye', 'f', 'tear', 'injection', '2.3', '3', '4', '4', '42', '4', '42', '42', '42', '4', 'f', '', 'f', 'f'),
(2, '2016-09-27-1', 'dry', 'Flare', 'Synichea', 'P.C.O', 'cells', 'csme', 'cupped', '', '6/4', '4', 'red eye', 'd', 'tear', 'injection', '2.3', '3', '4', '42', '42', '4', '42', '4', '4', '42', '', 'd', 'd', 'd', 'dry', 'Flare', 'Synichea', 'P.C.O', 'cells', 'csme', 'cupped', 'd', '6/4', '42', 'red eye', 'd', 'tear', 'injection', '2.3', '3', '4', '4', '42', '4', '42', '42', '42', '4', 'd', '', 'd', 'd'),
(4, '2016-09-21-1', 'dry', 'Flare', 'Synichea', 'P.C.O', 'cells', 'csme', 'cupped', 'e', '6/4', '34', 'red eye', 'e', 'tear', 'injection', '43', '234', '33', '243', '34', '34', '34', '3', '3', '3', '', 'e', 'e', 'e', 'dry', 'Flare', 'Synichea', 'P.C.O', 'cells', 'csme', 'cupped', 'f', '6/4', '3', 'red eye', 'f', 'tear', 'injection', '3', '3', '3', 'r', '4', '4', '4', '4', '4', '4', 'f', '', 'f', 'f'),
(5, '2016-09-24-1', 'dry', 'Flare', 'Synichea', 'P.C.O', 'cells', 'csme', 'cupped', 'e', '6/4', 'f', 'red eye', 'e', 'tear', 'injection', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', '', 'e', 'e', 'e', 'dry', 'Flare', 'Synichea', 'P.C.O', 'cells', 'csme', 'cupped', 'f', '6/4', 'f', 'red eye', 'f', 'tear', 'injection', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', '', 'f', 'f');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(100) NOT NULL,
  `ReminderDate` varchar(12) NOT NULL,
  `Note` text NOT NULL,
  `Time` time NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`ID`, `FullName`, `ReminderDate`, `Note`, `Time`) VALUES
(1, '2016-09-21-1', '2016-09-28', 'meeting', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE IF NOT EXISTS `patients` (
  `No` varchar(100) NOT NULL,
  `pport` varchar(255) NOT NULL,
  `title` varchar(50) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `age` int(100) NOT NULL,
  `tel` int(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `dEntry` varchar(255) NOT NULL,
  `verify` varchar(250) NOT NULL,
  PRIMARY KEY (`No`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`No`, `pport`, `title`, `fname`, `mname`, `lname`, `gender`, `dob`, `age`, `tel`, `address`, `dEntry`, `verify`) VALUES
('2016-09-21-1', 'neville.PNG', 'Mr.', 'Mwije', 'Zadoc', 'Neville', 'Male', '07/12/1992', 24, 752855715, 'Mbarara', '09/21/2016', 'verified.png'),
('2016-09-24-1', 'images.jpg', 'Mr.', 'samuel', 'kafeero', 'sam', 'Male', '10/06/1992', 23, 98765, 'mbarara', '10/24/2016', 'new'),
('2016-09-27-1', '[001305].jpg', 'Mr.', 'hh', 'mm', 'nn', 'Male', '09/06/2011', 5, 2147483647, 'mhhhg', '09/27/2016', 'verified.png');

-- --------------------------------------------------------

--
-- Table structure for table `procedurers`
--

CREATE TABLE IF NOT EXISTS `procedurers` (
  `pid` int(100) NOT NULL AUTO_INCREMENT,
  `procname` varchar(200) NOT NULL,
  `paNo` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `paNo` (`paNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `procedurers`
--

INSERT INTO `procedurers` (`pid`, `procname`, `paNo`, `status`) VALUES
(1, 'consultation', '2016-09-27-1', 'unconfirmed'),
(2, 'Dilation', '2016-09-27-1', 'unconfirmed'),
(3, 'Blood pressure', '2016-09-27-1', 'confirmed');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `qty` varchar(250) NOT NULL,
  `dateIn` date NOT NULL,
  `expiryDate` date NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_code`, `product_name`, `cost`, `price`, `supplier`, `qty`, `dateIn`, `expiryDate`) VALUES
(1, '001', 'Fiesta Green', '30000', '150', 'Colortex', '299', '2016-09-24', '2016-09-24'),
(2, '002', 'max', '30000', '1000', 'neville', '30', '2016-09-26', '2019-09-26');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE IF NOT EXISTS `purchases` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `suplier` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`transaction_id`, `invoice_number`, `date`, `suplier`, `remarks`) VALUES
(1, '09786564', '09/24/2016', 'neville', 'deliverd');

-- --------------------------------------------------------

--
-- Table structure for table `purchases_item`
--

CREATE TABLE IF NOT EXISTS `purchases_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `purchases_item`
--

INSERT INTO `purchases_item` (`id`, `name`, `qty`, `cost`, `invoice`) VALUES
(1, '001', 10, '100', '09786564');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(100) NOT NULL,
  `cashier` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `due_date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `balance` varchar(100) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`transaction_id`, `invoice_number`, `cashier`, `date`, `type`, `amount`, `due_date`, `name`, `balance`) VALUES
(1, 'RS-333373', 'teta', '09/28/2016', 'credit', '20', '28/09/2016', 'Mwije', '-150'),
(2, 'RS-006003', 'teta', '09/28/2016', 'cash', '300', '150', 'Mwije', '-150');

-- --------------------------------------------------------

--
-- Table structure for table `sales_order`
--

CREATE TABLE IF NOT EXISTS `sales_order` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice` varchar(100) NOT NULL,
  `product` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `profit` int(200) NOT NULL,
  `datesold` varchar(200) NOT NULL,
  `cashed` varchar(200) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sales_order`
--

INSERT INTO `sales_order` (`transaction_id`, `invoice`, `product`, `qty`, `amount`, `name`, `price`, `discount`, `profit`, `datesold`, `cashed`) VALUES
(1, 'RS-006003', '001', '2', '300', 'Fiesta Green', '150', '0', 400, '09/28/2016', 'cashed');

-- --------------------------------------------------------

--
-- Table structure for table `supliers`
--

CREATE TABLE IF NOT EXISTS `supliers` (
  `suplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `suplier_name` varchar(100) NOT NULL,
  `suplier_address` varchar(100) NOT NULL,
  `suplier_contact` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `tel` int(17) NOT NULL,
  PRIMARY KEY (`suplier_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `supliers`
--

INSERT INTO `supliers` (`suplier_id`, `suplier_name`, `suplier_address`, `suplier_contact`, `contact_person`, `tel`) VALUES
(1, 'neville', 'mbarara', '0752855715', 'samuel', 8767676);

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE IF NOT EXISTS `treatment` (
  `trtid` int(100) NOT NULL AUTO_INCREMENT,
  `medicineName` varchar(200) NOT NULL,
  `pNo` varchar(100) NOT NULL,
  `received` varchar(200) NOT NULL,
  `date` varchar(250) NOT NULL,
  PRIMARY KEY (`trtid`),
  KEY `pNo` (`pNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`trtid`, `medicineName`, `pNo`, `received`, `date`) VALUES
(1, 'ddd', '2016-09-27-1', 'Not-yet', '09/28/16'),
(2, 'mmm', '2016-09-27-1', 'Not-yet', '09/28/16'),
(3, 'ddd', '2016-09-27-1', 'received', '09/28/16');
